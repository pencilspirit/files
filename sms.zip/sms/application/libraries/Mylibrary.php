<?php

class Mylibrary
{
    
    public function permission($data,$type)
    {
       
               
$CI =& get_instance();
$CI->load->model('aclmodel');
$status=$CI->aclmodel->checking($data,$type);

     if($status!=false)
     {
        $controld=TRUE;
     }  else {
         $controld=FALSE;
     }
     return  $controld;  
    }
    
    
}

?>