<?php



class Aclpermission
{
    
    
    function addpermission($username){
         $CI =& get_instance();
         $CI->load->model('aclpermissionmodel');
$data=$CI->aclpermissionmodel->checking($username);
$accept;
if($data=='add'or $data=='full')
{
   
    $accept= TRUE;
    }  else {
       $accept=FALSE; 
    }
    return $accept;
    }


    public function editpermission($username)
    {
         $CI =& get_instance();
         $CI->load->model('aclpermissionmodel');
$data=$CI->aclpermissionmodel->checking($username);
$accept;
if($data=='edit'or $data=='full')
{
   
    $accept= TRUE;
    }  else {
       $accept=FALSE; 
    }
    return $accept;
    }
 function deletepermission($username){
        $CI =& get_instance();
         $CI->load->model('aclpermissionmodel');
$data=$CI->aclpermissionmodel->checking($username);
$accept;
if($data==='delete' or $data==='full')
{
    
 $accept= TRUE;
    }  else {
       $accept=FALSE; 
    }
    return $accept;
        
    }


    public function userpermission($user)
    {
       
               
 $CI =& get_instance();
         $CI->load->model('aclpermissionmodel');
$data=$CI->aclpermissionmodel->checking($user);


switch ($data)
        {
            case 'full':return 1;
                break;
            case 'edit':return 2;
                break;
            case 'add':return 3;
                break;
            case 'read':return 4;
                break;
            default :return 0;
                break;
        }
   
}
}
?>