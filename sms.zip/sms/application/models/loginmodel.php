<?php
class Loginmodel extends CI_Model{
    function __construct() {
        parent::__construct();
    }
    function loginined($user,$pass){
        $flag=FALSE;
        $this->db->select()->from('user')->where('username',$user)->where('userpass',$pass);
        $data=  $this->db->get();
        if ( $data->num_rows() >0 ){
          $flag= TRUE;
      }  else {
          $flag=FALSE;
      }
        return $flag;
    }
    function deletesms($id){
        $this->db->where('id',$id);
        $this->db->delete('sms');
    }
    function deleteemail($id){
         $this->db->where('id',$id);
        $this->db->delete('email');
    }
    function record_count(){
         return $this->db->count_all("user");
    }
}
?>
