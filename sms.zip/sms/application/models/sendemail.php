<?php
class Sendemail extends CI_Model{
    function __construct() {
        parent::__construct();
    }
    function sendunknowemail($data,$sender)
    {
        
        
        $this->db->select()->from('user');
        $sql=$this->db->get();
           foreach ($sql->result() as $row) {
           $this->load->database();
           $this->db->reconnect();
                   
                 $email= trim($row->email);  
                 
                 $sender=trim($row->useremail);
           
        }
       
        $Name ="Sridhar";
$recipient = $sender; 
$mail_body =$data;
$subject = 'Error in request';
$header = "From: ". $Name . " <" . $email . ">\r\n"; 

mail($recipient, $subject, $mail_body, $header);	
    }
}
?>
