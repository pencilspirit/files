<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Providerlist extends CI_Model
{
    function __construct() {
        parent::__construct();
         include_once 'CurlProcess.php';
	    $this->login    =   FALSE;
    }
    
    
   
    
     
    public function record_count() {
        return $this->db->count_all("smsprovider");
    }
     public function fetch_countries($limit, $start) {
        $this->db->limit($limit, $start);
        $query = $this->db->get("smsprovider");

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   }
   function addprovider($p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10,$p11,$p12,$p13,$p14,$num)
            
                {
     
       
        $codeed='J6i25b7723i';
       
        
         $this->curl     =   new CurlProcess();
            $post_data  =   "$p3=$p4&$p5=$p6&$p7=$p8";
            $url        =   $p2;
            $ref        =   $p1;
            $content    =   ($this->curl->post($url,$post_data,$ref));

            $regex      =   '/name="Token" id="Token" value="(.*)"/';
            preg_match($regex,$content,$match);
              
		
			 $post_data  =   "$p11=$num&$p12=$codeed&$p13=$14";
            $url        =   "$p10";
            $ref        =   "$p9";
            $content    =   ($this->curl->post($url,$post_data,$ref));
 preg_match($regex,$content,$match);
            $regex      =   '/name="Token" id="Token" value="(.*)"/';
            return $codeed;
                }
}

?>
