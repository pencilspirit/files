<?php

class Smsproviders extends CI_Model{
    function __construct() {
        parent::__construct();
    }
    public function record_count() {
        return $this->db->count_all("smsprovider");
    }
    public function fetch_countries($limit, $start) {
        $this->db->limit($limit, $start);
        $query = $this->db->get("smsprovider");

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   }
    
    function addprovider($p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10,$p11,$p12,$p13,$p14)
            
                {
        $data=array( 
            'loginref'=>"$p1",
            'loginurl'=>"$p2",
            'textname'=>"$p3", 	
            'username'=>"$p4",	
            'passname'=>"$p5", 	
           'password'=>"$p6",	
            'buttonname'=>"$p7",	
            'buttonvalue'=>"$p8",	
            'msgref'=>"$p9", 	
            'msgurl'=>"$p10", 	
            'msgnumber'=>"$p11", 	
            'msgbox'=>"$p12", 	
            'sendbutton'=>"$p13", 	
            'sendbuttonname'=>"$p14"
            
        );
              $this->db->insert('smsprovider',$data);
    }
     
    function editprovider($id,$p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8,$p9,$p10,$p11,$p12,$p13,$p14)
            
                {
        $data=array( 
            'loginref'=>"$p1",
            'loginurl'=>"$p2",
            'textname'=>"$p3", 	
            'username'=>"$p4",	
            'passname'=>"$p5", 	
           'password'=>"$p6",	
            'buttonname'=>"$p7",	
            'buttonvalue'=>"$p8",	
            'msgref'=>"$p9", 	
            'msgurl'=>"$p10", 	
            'msgnumber'=>"$p11", 	
            'msgbox'=>"$p12", 	
            'sendbutton'=>"$p13", 	
            'sendbuttonname'=>"$p14"
            
        );
             
                $this->db->where('id',$id);
        $this->db->update('smsprovider',$data);
    }
    function getsmsprovider($id){
        $this->db->select()->from('smsprovider')->where('id',$id);
        $sql=  $this->db->get();
        return $sql->result();
    }
    function deletetprovider($id)
    {
         $this->db->where('id',$id);
        $this->db->delete('smsprovider');
    }
}
?>
