<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Group extends CI_Model
{
    function __construct() {
        parent::__construct();
    }
    function getgroup()
        {
        $this->db->select()->from('Group');
          $sql=$this->db->get();
       
        return $sql->result();
    }
     function delete($id){
         
        
       $this->db->where('id',$id);
        $this->db->delete('Group');
       
         
   
    }
    function getmembergroup(){
        $this->db->select()->from('smsgroup');
          $sql=$this->db->get();
       $i=0;
        $data=array();
       foreach ($sql->result() as $row) {
           
                 $data[$i]= $row->gname;  
                 
                 $i++;
    }
    return $data; 
    }
    function getnumberforsendmessage($group){
        $this->db->distinct();
        $this->db->select()->from('smsgroup')->where('gname',$group);
        $sql=$this->db->get();
       $data=array();
       $i=0;
       foreach ($sql->result() as $row) {
           
                 $data[$i]= $row->number;  
                 $i++;
                
    }
    return $data; 
    }
    function getuniquenumberforsendmessage(){
        $this->db->distinct();
        $this->db->select()->from('members');
        $sql=$this->db->get();
        $i=0;
         $data=array();
       foreach ($sql->result() as $row) {
           
                 $data[$i]= $row->email;  
                 
                 $i++;
    }
    return $data; 
    }
    function uniquenumbergetnumber($email){
         $this->db->select()->from('members')->where('email',$email);
        $sql=$this->db->get();
        $i=0;
       foreach ($sql->result() as $row) {
           
                 $data[$i]= $row->number;  
                 
                 $i++;
    }
    return $data; 
    }
     function sendedmessageslist()
        {
        $this->db->select()->from('sms');
          $sql=$this->db->get();
       
        return $sql->result();
    }
    public function record_count() {
        return $this->db->count_all("sms");
    }
     public function fetch_countries($limit, $start) {
        $this->db->limit($limit, $start);
        $query = $this->db->get("sms");

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   }
    public function sendsms_count() {
        return $this->db->count_all("sms");
    }
     public function email_count() {
        return $this->db->count_all("email");
    }
    public function members_count() {
        return $this->db->count_all("members");
    }
    public function provider_count() {
        return $this->db->count_all("members");
    }
    
}

?>
