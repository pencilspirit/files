<?php
class Getmaildata extends CI_Model{
    function __construct() {
        parent::__construct();
    }
    function fetchsubject(){
        $this->load->database();
$this->db->reconnect();

        $this->db->select()->from('email')->where('status',1)->limit(1);
        $query = $this->db->get();
         
     $this->load->database();
$this->db->reconnect();

              
              foreach ($query->result() as $row) {
           $this->load->database();
$this->db->reconnect();
                    $id=$row->id;
                 $data[0]= $row->subject;  
                 $data[1]=$row->body;
                 $data[2]=$row->sender;
                
                 

            
        }
        $goup=array('status'=>0  );
         $this->db->where('id',$id);
        $this->db->update('email',$goup);
        
        return $data;
    }
}
?>
