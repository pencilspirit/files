<?php
class Asms extends CI_Model
{
	
		 var $login;
        var $curl;
        var $token; 
    function __construct() {
        parent::__construct();
		 include_once 'CurlProcess.php';
	    $this->login    =   FALSE;
		
		
	}
	  function sendsms($number,$sub)
   {
	  $this->load->database();
          $this->db->reconnect();
               $mainid;
        
              $idarray=array();
              $i=0;
              
              $count=$this->db->count_all("smsprovider");
              if($count>0){
              $this->db->select()->from('status');
              $sql=$this->db->get();
                foreach ($sql->result() as $row) {
                $this->load->database();
                $this->db->reconnect();                 
                $value= trim($row->value);  
                $date= $row->date;
                $id=  trim($row->id);
              };
              $today=date('Y-m-d');
              if($date!=$today){
                  $status=array('value'=>1,
                  'date'=>date('Y-m-d'));
                  $this->load->database();
           $this->db->reconnect();
           $this->db->where('id',$id);
          $this->db->update('status',$status);
          $this->db->select()->from('status');
              $sql=$this->db->get();
                foreach ($sql->result() as $row) {
                $this->load->database();
                $this->db->reconnect();                 
                $value= trim($row->value);  
                $date=  trim($row->date);
                $id=  trim($row->id);
              }
                  
              }
              
              $this->db->select()->from('smsprovider');
              $idlist=  $this->db->get();  
               foreach ($idlist->result() as $irow) {
                            $this->load->database();
                            $this->db->reconnect();
                            $idarray[$i]=$irow->id;
                            $i++;
              }
              sort($idarray);
             
              if($value>$count*100){
                $this->db->select()->from('user');
             $userlist=  $this->db->get();  
               foreach ($userlist->result() as $urow) {
                            $this->load->database();
                            $this->db->reconnect();
                            $email=$urow->email;
                            $useremail=$urow->useremail; 
              }
            
                $to = $useremail;
                $subject = "error in request";
                $message = "Sorry, Your SMSs is finish ";
                $from = $email;
                $headers = "From:" . $from;
                mail($to,$subject,$message,$headers);
              }else{
              for($j=0;$j<  count($idarray);$j++){
                     
                  
                  $k=$j+1;
                  if($j*100<$value and $value < ($k*100)+1) {                   
                      $mainid=$idarray[$j];
                      break;
                  }
                 
              }
              $this->db->select()->from('smsprovider')->where('id',$mainid);
              $smsdata=  $this->db->get();
                      foreach ($smsdata->result() as $srow) {
                           $loginref=$srow->loginref;
                           $loginurl=$srow->loginurl;
                           $textname=$srow->textname; 
                           $username=$srow->username;  
                           $passname=$srow->passname;
                           $password=$srow->password;
                           $buttonname=$srow->buttonname;
                           $buttonvalue=$srow->buttonvalue;
                           $msgref=$srow->msgref;
                           $msgurl=$srow->msgurl;
                           $msgnumber=$srow->msgnumber;
                           $msgbox=$srow->msgbox;	
                           $sendbutton=$srow->sendbutton;	
                           $sendbuttonname=$srow->msgbox;}


                      		$subject=trim($sub);
	    $this->curl     =   new CurlProcess();
		  $post_data  =   "$textname=$username&$passname=$password&$buttonname=$buttonvalue";
            $url        =   $loginurl;
            $ref        =   $loginref;
            $content    =   ($this->curl->post($url,$post_data,$ref));

            $regex      =   '/name="Token" id="Token" value="(.*)"/';
            preg_match($regex,$content,$match);
              
		
			 $post_data  ="$msgnumber=$number&$msgbox=$subject&$sendbutton=$sendbuttonname";
            $url        =   "$msgurl";
            $ref        =   "$msgref";
            $content    =   ($this->curl->post($url,$post_data,$ref));
              preg_match($regex,$content,$match);
            $regex      =   '/name="Token" id="Token" value="(.*)"/';
            
              $mail=array('number'=>$number,
                        'body'=>$subject,
                        'date'=>date('Y-m-d H:i:s')
                  
                );
              $status=array('value'=>$value+1,
                  'date'=>date('Y-m-d')
                  
                  );
            $this->load->database();
            $this->db->reconnect();
            $this->db->insert('sms',$mail);
            
	   $this->load->database();
           $this->db->reconnect();
           $this->db->where('id',$id);
          $this->db->update('status',$status);
              
              }
        
        
        }else{
             $this->db->select()->from('user');
             $userlist=  $this->db->get();  
               foreach ($userlist->result() as $urow) {
                            $this->load->database();
                            $this->db->reconnect();
                            $email=$urow->email;
                            $useremail=$urow->useremail; 
              }
            
                $to = $useremail;
                $subject = "error in request";
                $message = "You Dont have any sms provider, Please add any sms providers";
                $from = $email;
                $headers = "From:" . $from;
                mail($to,$subject,$message,$headers);

        }
        
     



   }
  
   
}

?>