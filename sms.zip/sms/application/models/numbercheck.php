<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Numbercheck extends CI_Model{
    function __construct() {
        parent::__construct();
    }
    function numberishere($number){
        $data;
        $this->load->database();
$this->db->reconnect();

        $this->db->select()->from('smsgroup')->where('number',$number);
        $sql=  $this->db->get();

        if ( $sql-> num_rows() >0 ){
          $data= 1;
      }  else {
          $data=0;
      }
      return $data;
    }
    function groupishere($gname){
        $this->load->database();
$this->db->reconnect();

        $data;
        $this->db->select()->from('smsgroup')->where('gname',$gname);
        $sql=  $this->db->get();

        if ( $sql-> num_rows() >0 ){
          $data= 1;
      }  else {
          $data=0;
      }
      return $data;
    }
    function getgroupnumber($group){
         $this->db->select()->from('smsgroup')->where('gname',$group);
        $query = $this->db->get();
        $i=0;
         foreach ($query->result() as $row) {
           
                 $data[$i]= $row->number;  
                 
                 $i++;
    }
    return $data; 
}

}

?>
