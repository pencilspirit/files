<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Smsmember extends CI_Model
{
    function __construct() {
        parent::__construct();
    }
    function getmember()
    {
        $this->db->select()->from('members');
        $sql=  $this->db->get();
        return $sql->result();
    }
    function editmember($id)
    {
        $this->db->select()->from('members')->where('id',$id);
        $sql=  $this->db->get();
        return $sql->result();
    }
      function updatedata($name,$phone,$email,$user,$id)
    {
          $goup=array(
            'gname'=>$user,
            'number'=>$phone
        );
        $data=array(
        'name'=>$name,
        'number'=>$phone,
        'email'=>$email,
        'groupname'=>$user);
         $this->db->where('id',$id);
        $this->db->update('members',$data);
         $this->db->where('mid',$id);
        $this->db->update('smsgroup',$goup);
    }
    function addmember($name,$phone,$email,$user){
        
        
        $data=array(
        'name'=>$name,
        'number'=>$phone,
        'email'=>$email,
        'groupname'=>$user);
        
       $this->db->insert('members',$data);
       
       
       
        $this->db->select()->from('members')->where('name',$name)->where('number',$phone)->where('groupname',$user);
        $sql=  $this->db->get();

        foreach ($sql->result() as $row) {
           
                 $value =$row->id;                        
        }
       $goup=array(
            'gname'=>$user,
            'number'=>$phone,
           'mid'=>$value
                  );
       
       $this->db->insert('smsgroup',$goup);
    }
    function deletemember($id,$gid)
    {
          
       $this->db->where('id',$id);
        $this->db->delete('members');
        $this->db->where('mid',$gid);
        $this->db->delete('smsgroup');
    }
    function cheching($number,$group){
         $data;
        $this->db->select()->from('members')->where('email',$number)->where('groupname',$group);
        $sql=  $this->db->get();
        
        
        if ( $sql-> num_rows() >0 ){
          $data= TRUE;
      }  else {
          $data=FALSE;
      }
      
      return $data;
    }
    function chechingedit($id,$group){
         $data;
        $this->db->select()->from('members')->where('id',$id)->where('groupname',$group);
        $sql=  $this->db->get();
        
        
       if ( $sql-> num_rows() >0 ){
          $data= TRUE;
      }  else {
          $data=FALSE;
      }
      return $data;
    }
    function getgroupname($id)
    {
         $this->db->select()->from('members')->where('id',$id);
        $sql=  $this->db->get();

        foreach ($sql->result() as $row) {
           
                 $value =$row->groupname;                        
        }
       
        return $value;
    }
    function getgroupnumber($id){
        $this->db->select()->from('members')->where('id',$id);
        $sql=  $this->db->get();

        foreach ($sql->result() as $row) {
           
                 $value =$row->number;                        
        }
        
    }
   
    
}

?>
