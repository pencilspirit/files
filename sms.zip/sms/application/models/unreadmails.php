<?php
class Unreadmails extends CI_Model{
    function __construct() {
        parent::__construct();
    }
    function unreadmail(){
        $this->db->select()->from('user');
        $sql=$this->db->get();
           foreach ($sql->result() as $row) {
           $this->load->database();
           $this->db->reconnect();
                   
                 $data= trim($row->email);  
                 $pass=trim($row->password);
                 $useremail=trim($row->useremail);
           
        }
        
        
        $flag=FALSE;
	 $mbox = imap_open("{imap.gmail.com:993/imap/ssl}INBOX","$data", "$pass")
         or die("can't connect: " . imap_last_error());
		 $numMessages = imap_num_msg($mbox);
                $i = $numMessages; 
while($i!=0){
 $headers = imap_headerinfo($mbox, $i);
    if($headers->Unseen == 'U') {
        
       
    $header = imap_header($mbox, $i);

    $fromInfo = $header->from[0];
    $replyInfo = $header->reply_to[0];

    $details = array(
        "fromAddr" => (isset($fromInfo->mailbox) && isset($fromInfo->host))? $fromInfo->mailbox . "@" . $fromInfo->host : "",
       "fromName" => (isset($fromInfo->personal)) ? $fromInfo->personal : "",
        "replyAddr" => (isset($replyInfo->mailbox) && isset($replyInfo->host))? $replyInfo->mailbox . "@" . $replyInfo->host : "",
      
        "subject" => (isset($header->subject))
            ? $header->subject : "",
       
    );
    if($details["fromAddr"]==$useremail){
        if(trim($details['subject'])!=""){
        $flag=TRUE;
        $body= strip_tags(imap_fetchbody($mbox, $i, 2));
        $this->load->database();
            $this->db->reconnect();
       $goup=array(
            'subject'=>$details['subject'],
            'body'=>$body,
           'date'=> date('Y-m-d H:i:s'),
           'sender'=>$details['fromAddr'],
           'status'=>1
                  );
       
       $this->db->insert('email',$goup);
   
    }  else {
         
        $email = "$data"; 
        $Name ="Sridhar";
         $body= strip_tags(imap_fetchbody($mbox, $i, 2));
$recipient = $useremail; 
$mail_body ='No subject is not allowed  ';
$subject = 'Error in request';
$header = "From: ". $Name . " <" . $email . ">\r\n"; 

mail($recipient, $subject, $mail_body, $header);
        
    }
    }
    }
    $this->load->database();
            $this->db->reconnect();
    
    $i--;
}


return $flag;
    }
}

?>
