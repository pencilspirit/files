<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Numberchecked extends CI_Model{
    function __construct() {
        parent::__construct();
    }
    function numberishere($number){
        $this->load->database();
            $this->db->reconnect();
        $data;
        $this->db->select()->from('smsgroup')->where('number',$number);
        $sql=  $this->db->get();

        if ( $sql-> num_rows() >0 ){
          $data= TRUE;
      }  else {
          $data=FALSE;
      }
      return $data;
    }
     function getnumberbygroupname($group){
            $this->load->database();
            $this->db->reconnect();

          $this->db->select('numbers')->from('smsgroup')->where('gname', $group); 
      $query = $this->db->get();
         
     
              
              foreach ($query->result() as $row) {
           
                 echo $row->number;                

            
        }
     }
    
}

?>
