<?php  if(!isset($_SESSION['user'])){
    
      redirect('smsmaincontrol/login');
}else{
    
    
    ?>
	
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>SMS</title>
 

  <!-- Le styles -->
  <link href="<?php echo base_url();?>css/bootstrap.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/style.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/docs.css" rel="stylesheet">
  <link rel='stylesheet' href='<?php echo base_url();?>css/prettify.css' />

	<link rel="stylesheet" href="<?php echo base_url();?>css/fullcalendar.css">
	<link rel="stylesheet" href="<?php echo base_url();?>css/toastr.css">
 
  <script src="<?php echo base_url();?>js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>js/bootstrap.js"></script>
  <script src="<?php echo base_url();?>js/jquery.knob.js"></script>
  <script src="<?php echo base_url();?>js/jquery.sparkline.min.js"></script>
  <script src="<?php echo base_url();?>js/toastr.js"></script>
  <script src="<?php echo base_url();?>js/jquery.tablesorter.min.js"></script>
  <script src="<?php echo base_url();?>js/jquery.peity.min.js"></script>
  <script src="<?php echo base_url();?>js/fullcalendar.min.js"></script>
  <script src="<?php echo base_url();?>js/gcal.js"></script>
  <script src="<?php echo base_url();?>js/prettify.js"></script>
 

  <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
  </head>
  
  <body>
  
	   <div class="navbar navbar-fixed-top">
	
			<div class="navbar-inner">
				
				<div class="container">
					
					<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</a>
					
					<a class="brand pull-left" href="./">
						<img style="margin-right:20px" src="<?php echo base_url();?>image/group_logo.png"/>				
					</a>		
					
					<div class="nav-collapse">
						<ul class="nav pull-right">
					
							<li class="dropdown">
								
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" style="margin-top:10px">
									<i class="icon-user"></i> 
									admin									<b class="caret"></b>
								</a>
								
								<ul class="dropdown-menu">
									 <li><a href="<?php echo base_url(); ?>index.php/sms/myaacount">My Profile</a></li>
									<li class="divider"></li>
                                                                        <li><a href="<?php echo base_url();?>index.php/smsmaincontrol/logout">Logout</a></li>
								</ul>
								
							</li>
						</ul>
						
					</div><!--/.nav-collapse -->	
			
				</div> <!-- /container -->
				
			</div> <!-- /navbar-inner -->
			
		</div> <!-- /navbar -->
		
		<!-- Main Content
    ================================================== -->
		<div class="main">

			<div class="main-inner">

			    <div class="container">
			    
			    	<div class="row">
			    	
							<div class="span3 bs-docs-sidebar" style="margin-top:50px; min-height:600px">
								<!-- Secondary vertical navigation
						    ================================================== -->
								<ul class="nav nav-list bs-docs-sidenav">
								  <li class=' sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/login"><img style="margin-right:20px;" src="<?php echo base_url();?>image/glyphicons_041_charts.png"/>Dashboard</a></li>
								  <li class=' sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/sendsmsnow"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_124_message_plus.png"/>Send Message</a></li>
								  <li class='  sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/sendsmslist"><img style="margin-right:25px" src="<?php echo base_url();?>image/glyphicons_123_message_out.png"/>SMS log</a></li>
								  <li class='  sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/receiveemail"><img style="margin-right:26px" src="<?php echo base_url();?>image/glyphicons_077_headset.png"/>Email log</a></li>
								  <li class='active sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/smsprovider"><img style="margin-right:23px" src="<?php echo base_url();?>image/glyphicons_127_message_flag.png"/>Sms Provider</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/getgroups"><img style="margin-right:18px" src="<?php echo base_url();?>image/glyphicons_024_parents.png"/>Contact Groups</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/alcontacts"><img style="margin-right:19px" src="<?php echo base_url();?>image/glyphicons_024_parents.png"/>All Contacts</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/myaccout"><img style="margin-right:26px" src="<?php echo base_url();?>image/glyphicons_044_keys.png"/>My Account</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/setup"><img style="margin-right:16px" src="<?php echo base_url();?>image/glyphicons_137_cogwheels.png"/>Setup</a></li>
									
								</ul>
								
							</div>
                                       <script type="text/javascript" charset="utf-8">
	
	$(document).ready(function() {
		
		
		//Update SMS details
		$("#sms_form").submit(function() {
					
			$.ajax({
				
				url: $(this).attr('action'),
				type: "POST",
				dataType: 'json',
				data: $("#sms_form").serialize(),
				success: function(data) {
					if( data.success = true )
					{
						toastr.success('New SMS profile added!');
					}
					if( data.errors != undefined )
					{
						alert(data.errors);
					}
				}
				
			});
			
			return false;
			
		});
	});
</script>

		
			<div class="row">
                           
				<div class="span9"  style="margin-top:40px; ">
				<h4>Add Sms Provider</h4>
						<div class="well well-min well-col">
                                                    <?php echo form_open('smsmaincontrol/addprovider'); ?>
                                                    <div class="span4" style="display:">
							<div class="control-group  ">								
								<div class="controls"><label class="control-label " for="inputSmsMessage">LogIn Reference Url</label>
                                                                   
                                                                    <input type="text" name="refurl" value=" <?php echo set_value('refurl'); ?>" class='span3' id="refurl" />	
                                                                 </div><!-- /controls -->
							</div><!-- /control-group -->
						    </div><!-- /span3 -->
									
						   <div class="span4" style="display:">
							<div class="control-group  ">								
							       <div class="controls"><label class="control-label " for="inputSmsMessage">Login  Url</label>
							       <input type="text" name="logurl" value="<?php echo set_value('logurl'); ?>" id="logurl" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						   </div><!-- /span3 -->
                                                   <div class="span4" style="display:">
							<div class="control-group  ">								
								<div class="controls"><label class="control-label " for="inputSmsMessage">Username Box Name</label>
								<input type="text" name="uboxename" value="<?php echo set_value('uboxename'); ?>" id="uboxename" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						    </div><!-- /span3 -->
									
						   <div class="span4" style="display:">
							<div class="control-group  ">								
							       <div class="controls"><label class="control-label " for="inputSmsMessage">Username</label>
							       <input type="text" name="username" value="<?php echo set_value('username'); ?>" id="username" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						   </div><!-- /span3 -->
                                                   <div class="span4" style="display:">
							<div class="control-group  ">								
								<div class="controls"><label class="control-label " for="inputSmsMessage">Password Box Name </label>
								<input type="text" name="pboxname" value="<?php echo set_value('pboxname'); ?>" id="pboxname" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						    </div><!-- /span3 -->
                                                    <div class="span4" style="display:">
							<div class="control-group  ">								
								<div class="controls"><label class="control-label " for="inputSmsMessage">Password  </label>
								<input type="text" name="password" value="<?php echo set_value('password'); ?>" id="password" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						    </div><!-- /span3 -->
									
						   <div class="span4" style="display:">
							<div class="control-group  ">								
							       <div class="controls"><label class="control-label " for="inputSmsMessage">Login Button Name</label>
							       <input type="text" name="buttonname" value="<?php echo set_value('buttonname'); ?>" id="buttonname" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						   </div><!-- /span3 -->
                                                   <div class="span4" style="display:">
							<div class="control-group  ">								
								<div class="controls"><label class="control-label " for="inputSmsMessage">Login Button Value</label>
								<input type="text" name="logbuttonvalue" value="<?php echo set_value('logbuttonvalue'); ?>" id="logbuttonvalue" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						    </div><!-- /span3 -->
									<div class="span4" style="display:">
							<div class="control-group  ">								
							       <div class="controls"><label class="control-label " for="inputSmsMessage">Send Message Url </label>
							       <input type="text" name="messageurl" value="<?php echo set_value('messageurl'); ?>" id="messageurl" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						   </div><!-- /span3 -->
                                                   <div class="span4" style="display:">
							<div class="control-group  ">								
								<div class="controls"><label class="control-label " for="inputSmsMessage">Send Message Reference Url </label>
								<input type="text" name="msgrefurl" value="<?php echo set_value('msgrefurl'); ?>" id="msgrefurl" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						    </div><!-- /span3 -->
						   <div class="span4" style="display:">
							<div class="control-group  ">								
							       <div class="controls"><label class="control-label " for="inputSmsMessage">Contact Number Box  Name</label>
							       <input type="text" name="senderboxname" value="<?php echo set_value('senderboxname'); ?>" id="senderboxname" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						   </div><!-- /span3 -->
                                                   <div class="span4" style="display:">
							<div class="control-group  ">								
								<div class="controls"><label class="control-label " for="inputSmsMessage">Message Box Name</label>
								<input type="text" name="msgboxname" value="<?php echo set_value('msgboxname'); ?>" id="msgboxname" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						    </div><!-- /span3 -->
									
						   <div class="span4" style="display:">
							<div class="control-group  ">								
							       <div class="controls"><label class="control-label " for="inputSmsMessage">Send Button Name</label>
							       <input type="text" name="sendbouttonname" value="<?php echo set_value('sendbouttonname'); ?>" id="sendbouttonname" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						   </div><!-- /span3 -->
                                                   <div class="span4" style="display:">
							<div class="control-group  ">								
								<div class="controls"><label class="control-label " for="inputSmsMessage">Send Button Value</label>
								<input type="text" name="sendbuttonvalue" value="<?php echo set_value('sendbuttonvalue'); ?>" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						    </div><!-- /span3 -->
									
						   <hr>
                                                   <br><br><br>			
                                                   
                                                   
						   <div class="span4" >
							<div class="control-group  ">								
							       <div class="controls"><label class="control-label " for="inputSmsMessage">Your Phone Number</label>
							       <input type="text" name="yournumber" value="<?php echo set_value('yournumber'); ?>" id="yournumber" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						   </div><!-- /span3 --><br><br><br>
                                                   
                                                   <?php if($_SESSION['code']=='set') {?>
                                                   <div class="span4" style="display:">
							<div class="control-group  ">								
								<div class="controls"><label class="control-label " for="inputSmsMessage">Activation Code</label>
                                                                    
								<input type="text" name="verificationcode" value="" class='span3' />								</div><!-- /controls -->
							</div><!-- /control-group -->
						    </div><!-- /span3 -->
									
						   
					
						
							
							 <div class="span4" style="display:">
							<div class="controls">
								
								<button class="btn btn-danger" type="save"><i class="icon-ok icon-white"></i> Save Provider </button>
							</div><!-- /controls -->
                                                         </div>
                                                        <div class="controls">
                                                            
                                                            <?php echo form_close(); 
                                                           
                                                                ?>
                                                            
								 <?php echo form_open('smsmaincontrol/addprovidered'); 
                                                                  
                                                                 ?>
								<button class="btn btn-danger" type="save"><i class="icon-ok icon-white"></i> Back To Registration </button>
							</div><!-- /controls -->
								<?php }
                                                                else { ?>
                                                        <div class="controls" style="margin-top:100px; ">
								
                                                            <button class="btn btn-danger" type="save" style="margin-top: 3%;margin-left: 5%;"><i class="icon-ok icon-white"></i> Get Verification Code</button>
							</div><!-- /controls -->
                                                        
                                                        <?php
                                                                }
                                                        ?>
						</form>	
						
                                                    <?php echo form_close(); ?>
                                                <br><br><br>
					</div><!-- /well -->
                                       
                                        
				</div><!-- /span9 -->
                                
			</div><!-- /row -->

		</div><!-- /span9 -->
                
		
</div><!-- /row -->
					    

			    </div> <!-- /container -->

			</div> <!-- /main-inner -->

  

			<div class="footer-inner">
				
				<div class="container">
					
					<div class="row">
						
		    			<div class="span12">
		    				&copy; Sridhar 2013 <a href="#"></a>.
		    			</div> <!-- /span12 -->
		    			
		    		</div> <!-- /row -->
		    		
				</div> <!-- /container -->
				
			</div> <!-- /footer-inner -->

  </body>
</html>

<?php }?>
