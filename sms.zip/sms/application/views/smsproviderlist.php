<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!DOCTYPE html>

<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ -->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8" />

  <meta name="viewport" content="width=device-width" />

  <title>PlusKb innovation</title>
   
  <link rel="stylesheet" href="<?php echo base_url();?>stylesheets/foundation.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>stylesheets/app.css">
  <script src="<?php echo base_url();?>javascripts/modernizr.foundation.js"></script>
</head>
<body style="background:url(<?php echo base_url();?>image/background.png) repeat-x" >
    
        
<div class="twelve columns">

    <h1>Member</h1>
</div>
    
    
    <div class="columns seven">
     
    </div>
             
</div>
     <div class="six columns">
 
     
      <table>
     <?php
foreach($results as $data) {?>
              	
             <tr><td><?php echo $data->username;?> </td><td><?php echo $data->password;?></td><td><?php echo $data->loginurl ;?></td><td><a href="">Edit</a></td></tr>
    <?php
}
?>
             </table>
   <p><?php echo $links; ?></p>
     </div>

    <script>
    $(window).load(function(){
      $("#featured").orbit();
    });
    </script> 
  
</body>
</html>
