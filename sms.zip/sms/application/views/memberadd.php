<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!DOCTYPE html>

<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ -->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8" />

  <meta name="viewport" content="width=device-width" />

  <title>PlusKb innovation</title>
   
  <link rel="stylesheet" href="<?php echo base_url();?>stylesheets/foundation.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>stylesheets/app.css">
  <script src="<?php echo base_url();?>javascripts/modernizr.foundation.js"></script>
</head>
<body style="background:url(<?php echo base_url();?>image/background.png) repeat-x" >


    <div class="row "><br><br><br><br>
        <div class="twelve columns">
        
        <div class="five columns"> <?php echo form_open('member/addmember'); ?>
           
            <div class="row twelve">
                <div class="six columns"><label>Name</label></div>
                
                <div class="six columns">
                     <?php
      echo form_input('name', set_value('name'), 'id="name" autofocus');    
   ?>
                   </div>
            </div><br>
            <div class="row twelve">
                <div class="six columns"><label>Email</label></div>
                
                  <div class="six columns">
                      <?php
      echo form_input('email', "", 'id="email" autofocus');    
   ?>
</div></div>
            <br>
            <div class="row twelve">
                <div class="six columns"><label>Phone Number</label>
                </div>
                
                  <div class="six columns">
                    <?php
      echo form_input('phone', set_value('phone'), 'id="phone" autofocus');    
   ?></div></div>
            <br>
            <div class="row twelve">
                <div class="six columns"><label>Group</label></div>
                
                  <div class="six columns">
                      
                       <select name="usergroup" value="$rowedit->groupname" style="width: 168px;height:30px ">
                           <?php foreach ($row as $data ) { ?>
                                 <option value="<?php echo $data->groupname; ?>"><?php echo $data->groupname; ?></option><?php
                            
                            }
                            ?>
                            
</select>
                      
                      
                  </div>
            </div><br>
            <div class="row twelve">
               
                
                  <div class="six columns">
<input type="submit" value="Done" name="done" class="button"></div>
            <?php echo form_close(); ?>
            
                
                
                  <div class="six columns">
 <?php echo form_open('member/cancel'); ?>
		<input type="submit" value="Cancel" name="cancel" class="button" >
		<?php echo form_close(); ?></div></div>
           
        </div>
  <?php echo validation_errors(); ?>
    </div>
    </div>

     <script>
    $(window).load(function(){
      $("#featured").orbit();
    });
    </script> 
  
</body>
</html>
