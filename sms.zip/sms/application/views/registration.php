
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>SMS</title>
 

  <!-- Le styles -->
  <link href="<?php echo base_url();?>css/bootstrap.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/docs.css" rel="stylesheet">
	<link rel="<?php echo base_url();?>css/toastr.css">
  
    <script src="<?php echo base_url();?>js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>js/bootstrap.js"></script>
    <script src="<?php echo base_url();?>js/jquery.knob.js"></script>
    <script src="<?php echo base_url();?>js/d3.v3.min.js"></script>
    <script src="<?php echo base_url();?>js/jquery.sparkline.min.js"></script>
    <script src="<?php echo base_url();?>js/toastr.js"></script>
    <script src="<?php echo base_url();?>js/jquery.tablesorter.min.js"></script>
    <script src="<?php echo base_url();?>js/jquery.peity.min.js"></script>
    <script src="<?php echo base_url();?>js/fullcalendar.min.js"></script>
    <script src="<?php echo base_url();?>js/gcal.js"></script>
    <script src="<?php echo base_url();?>js/setup.js"></script>

  <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
  </head>
  
  <body>
  
	  <div class="navbar navbar-fixed-top">
	
			<div class="navbar-inner">
				
				<div class="container">
					
					<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</a>
                                    	  
					   <div style="margin-top:12px; margin-left:610px;margin-bottom:-90px;">
					<?php echo form_open('smsmaincontrol/login'); ?> 
                                               <input type="text" class="span2" placeholder="Username" name="email" id="email" style="width: 220px">
					  <input type="password" class="span2" placeholder="Password" name="password"  id="password"> <button type="submit" value="login" class="btn" style="margin-top:-10px;">Get Verification </button>
                                          <label style="color:red">Check Your Email</label><input type="text" class="span2" placeholder="Varification Cdoe" name="vcode"  id="vcode">
                                          <button type="submit" value="login" class="btn" style="margin-top:-10px;">Submit</button>
					<?php echo form_close(); ?>
                                    </div>
					
					 
								
					<a class="brand pull-left" href="./">
						<img style="margin-right:20px;" src="<?php echo base_url();?>image/group_logo.png"/>				
					</a>	
					
					<div class="nav-collapse">
						<ul class="nav pull-right">

						</ul>
						
					</div><!--/.nav-collapse -->	
			
				</div> <!-- /container -->
				
			</div> <!-- /navbar-inner -->
			
		</div> <!-- /navbar -->
		
		<!-- Main Content
    ================================================== -->
		<div class="main">

			<div class="main-inner">

						

									
	<div class="container" style="margin-top:120px;">
		<div class="row">
			
			<div class="span9 offset1">
				<div class="marketing">
						<div id="myCarousel" class="carousel slide marketing">
							<div class="carousel-inner">
								<div class="item active">
									<h1>Group SMS </h1>
									<br />
									<div class="span5">
										<p class="marketing-byline">Send the same SMS message  to 1000's of people instantly.</p>
										<p><i class="icon-ok icon-white"></i>  Business group messaging events or emergency drills</p>
										<p><i class="icon-ok icon-white"></i>  Schools messaging parents about events or off days</p>
										<p><i class="icon-ok icon-white"></i>  Small business SMS marketing</p>
										
										
									</div>
									<img style="margin-right:20px; height:250px" src="<?php echo base_url();?>image/bubble.png"/> 
								</div><!-- /active-item -->
								<div class="item">
									<h1>Features</h1>
									<br />
									<div class="span5">
										<p class="marketing-byline">Simple, easy to use interface</p>
										
										<p><i class="icon-ok icon-white"></i>  Contact manager</p>
										<p><i class="icon-ok icon-white"></i>  SMS provider Manager</p>
										
										<p><i class="icon-ok icon-white"></i>  SMS message log in & out</p>
									</div>
									<img style="margin-right:20px; height:250px" src="<?php echo base_url();?>image/envelope.png"/> 
								</div><!-- /item -->
								<div class="item">
									<h1>Setup </h1>
									<div class="span5">
										<p class="marketing-byline">Setup on your own SMS provider </p>
										<p><i class="icon-ok icon-white"></i> This appilication is fully free</p>
										<p><i class="icon-ok icon-white"></i>  FREE SETUP </p>
										<p><i class="icon-ok icon-white"></i>  Setup completed within 5 Mints</p>
									</div>
									<img style="margin-right:20px; height:250px" src="<?php echo base_url();?>image/envelope.png"/>
								</div><!-- /item -->
								<div class="item">
									<h1>Operation</h1>
									<div class="span5">
										<p class="marketing-byline">Sending messages to 1000's of people instantly!</p>
										<p><i class="icon-ok icon-white"></i>  Create a contact group</p>
										<p><i class="icon-ok icon-white"></i>  Add contacts to a group</p>										
										<p><i class="icon-ok icon-white"></i>  Just send an email to admin  </p>
                                        <p><i class="icon-ok icon-white"></i>  The mail subject specificy the Group name or contact Number </p>
										
									</div>
									<img style="margin-right:20px; height:250px" src="<?php echo base_url();?>image/peeps.png"/>
								</div><!-- /item -->
							</div><!-- /item active -->
							<a class="left carousel-control" data-slide="prev" href="#myCarousel" style="margin-left:-60px">‹</a>
							<a class="right carousel-control" data-slide="next" href="#myCarousel" style="margin-right:-60px">›</a>
						</div><!-- /carousel -->
					</div><!-- /carousel -->
				</div><!-- /marketing -->
			
		</div><!-- /row -->

	</div><!-- /container -->

				
				</div> <!-- /container -->

			</div> <!-- /main-inner -->

  

			
			<div class="footer-inner">
				
				<div class="container">
					
					<div class="row">
						
		    			<div class="span12">
		    				&copy; Sridhar 2013 <a href="#"></a>.
		    			</div> <!-- /span12 -->
		    			
		    		</div> <!-- /row -->
		    		
				</div> <!-- /container -->
				
			</div> <!-- /footer-inner -->
			

  </body>
</html>

