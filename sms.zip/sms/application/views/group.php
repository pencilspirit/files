<!DOCTYPE html>

<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ -->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8" />

  <meta name="viewport" content="width=device-width" />

  <title>PlusKb innovation</title>
   
  <link rel="stylesheet" href="<?php echo base_url();?>stylesheets/foundation.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>stylesheets/app.css">
  <script src="<?php echo base_url();?>javascripts/modernizr.foundation.js"></script>
</head>
<body style="background:url(<?php echo base_url();?>image/background.png) repeat-x" >
<div class="row">
<div class="twelve columns">
<div class="row twelve">
    <h1>GROUP</h1>
</div>
    
    <table>
    <div class="row twelve">
        <?php
        $i=1;
       foreach ($row as $data )
{
               ?>
        
        <tr><td><?php echo $i; ?></td><td><?php echo $data->groupname; ?></td>
            <td> <a href=" <?php echo base_url(); ?>index.php/sms/delete/<?php echo $data->id;?>" >Delete</a></td></tr>
        
        <?php $i++;
}
        ?>
        
    </table>
</div>
</div>
</div>

  
    <script>
    $(window).load(function(){
      $("#featured").orbit();
    });
    </script> 
  
</body>
</html>
