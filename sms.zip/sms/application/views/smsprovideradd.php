<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!DOCTYPE html>

<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ -->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8" />

  <meta name="viewport" content="width=device-width" />

  <title>PlusKb innovation</title>
   
  <link rel="stylesheet" href="<?php echo base_url();?>stylesheets/foundation.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>stylesheets/app.css">
  <script src="<?php echo base_url();?>javascripts/modernizr.foundation.js"></script>
</head>
<body style="background:url(<?php echo base_url();?>image/background.png) repeat-x" >
    
      <div class="row "><br><br><br><br>
        <div class="twelve columns">
        
        <div class="six columns"> <?php echo form_open('smsprovider/addprovider'); ?>
           
            <div class="row twelve">
                <div class="six columns"><label>LogIn Reference Url</label></div>
                
                <div class="six columns">
                     <?php
      echo form_input('refurl', set_value('refurl'), 'id="refurl" autofocus');    
   ?>
                   </div>
            </div><br>
            <div class="row twelve">
                <div class="six columns"><label>Login Username Box Name</label></div>
                
                  <div class="six columns">
                      <?php
      echo form_input('uboxename', set_value('uboxname'), 'id="uboxname" autofocus');    
   ?>
</div></div>
            <br>
            <div class="row twelve">
                <div class="six columns"><label>Login Password Box Name</label>
                </div>
                
                  <div class="six columns">
                    <?php
      echo form_input('pboxname', set_value('pboxname'), 'id="pboxname" autofocus');    
   ?></div></div>
            <br>
            <div class="row twelve">
                <div class="six columns"><label>Login Button name</label></div>
                
                  <div class="six columns">
                    <?php
      echo form_input('buttonname', set_value('buttonname'), 'id="buttonnam" autofocus');    
   ?></div>
            </div><br>
             <div class="row twelve">
                <div class="six columns"><label>Message Reference Url</label></div>
                
                  <div class="six columns">
                    <?php
      echo form_input('msgrefurl', set_value('msgrefurl'), 'id="msgrefurl" autofocus');    
   ?></div>
            </div><br>
             <div class="row twelve">
                <div class="six columns"><label>Sender Box Name </label></div>
                
                  <div class="six columns">
                    <?php
      echo form_input('senderboxname', set_value('senderboxname'), 'id="senderboxname" autofocus');    
   ?></div>
            </div><br>
             <div class="row twelve">
                <div class="six columns"><label>Send Button Name</label></div>
                
                  <div class="six columns">
                    <?php
      echo form_input('sendbouttonname', set_value('sendbouttonname'), 'id="sendbouttonname" autofocus');    
   ?></div>
            </div>
            <br>
            
            
      
           
        </div>
             <div class="six columns"> 
           
            <div class="row twelve">
                <div class="six columns"><label>LogIn Url</label></div>
                
                <div class="six columns">
                      <?php
      echo form_input('logurl', set_value('logurl'), 'id="logurl" autofocus');    
   ?>
                   </div>
            </div><br>
            <div class="row twelve">
                <div class="six columns"><label>User name</label></div>
                
                  <div class="six columns">
                      <?php
      echo form_input('username', set_value('username'), 'id="username" autofocus');    
   ?>
</div></div>
            <br>
            <div class="row twelve">
                <div class="six columns"><label>Password</label>
                </div>
                
                  <div class="six columns">
                    <?php
      echo form_input('password', set_value('password'), 'id="password" autofocus');    
   ?></div></div>
            <br>
            <div class="row twelve">
                <div class="six columns"><label>Login Button Value</label></div>
                
                  <div class="six columns">
                    <?php
      echo form_input('logbuttonvalue', set_value('logbuttonvalue'), 'id="logbuttonvalue" autofocus');    
   ?></div>
            </div><br>
             <div class="row twelve">
                <div class="six columns"><label>Message Url</label></div>
                
                  <div class="six columns">
                    <?php
      echo form_input('messageurl', set_value('messageurl'), 'id="messageurl" autofocus');    
   ?></div>
            </div><br>
             <div class="row twelve">
                <div class="six columns"><label>message Box name</label></div>
                
                  <div class="six columns">
                    <?php
      echo form_input('msgboxname', set_value('msgboxname'), 'id="msgboxname" autofocus');    
   ?></div>
            </div><br>
             <div class="row twelve">
                <div class="six columns"><label>Send Button Value</label></div>
                
                  <div class="six columns">
                    <?php
      echo form_input('sendbuttonvalue', set_value('sendbuttonvalue'), 'id="sendbuttonvalue" autofocus');    
   ?></div>
            </div><br>
            <div class="row twelve">
               
                
                  <div class="six columns">
</div>
            
            
                
                
                  <div class="six columns">
 </div></div>
           
        </div>
  <?php echo validation_errors(); ?>
    </div>
                <div class="row twelve">
               
                
                  <div class="six columns">
                   
		<input type="submit" value="Save" name="Save" class="button right " >
		<?php echo form_close(); ?>
</div>
          
            
                 <div class="six columns"><?php echo form_open('member/cancel'); ?>
		<input type="submit" value="Cancel" name="cancel" class="button" >
		<?php echo form_close(); ?>
 </div>
                
                 </div>
    </div>
    
    
    
       <script>
    $(window).load(function(){
      $("#featured").orbit();
    });
    </script> 
  
</body>
</html>
