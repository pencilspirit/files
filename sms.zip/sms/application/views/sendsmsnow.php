<?php  if(!isset($_SESSION['user'])){
    
      redirect('smsmaincontrol/login');
}else{
    
    
    ?>
	

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>SMS</title>
  

  <!-- Le styles -->
  <link href="<?php echo base_url();?>css/bootstrap.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/docs.css" rel="stylesheet">
  <link rel='stylesheet' href='<?php echo base_url();?>css/prettify.css' />

	<link rel="stylesheet" href="<?php echo base_url();?>css/fullcalendar.css">
	<link rel="stylesheet" href="<?php echo base_url();?>css/toastr.css">
 
  <script src="<?php echo base_url();?>js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>js/bootstrap.js"></script>
  <script src="<?php echo base_url();?>js/jquery.knob.js"></script>
  <script src="<?php echo base_url();?>js/jquery.sparkline.min.js"></script>
  <script src="<?php echo base_url();?>js/toastr.js"></script>
  <script src="<?php echo base_url();?>js/jquery.tablesorter.min.js"></script>
  <script src="<?php echo base_url();?>js/jquery.peity.min.js"></script>
  <script src="<?php echo base_url();?>js/fullcalendar.min.js"></script>
  <script src="<?php echo base_url();?>js/gcal.js"></script>
  <script src="<?php echo base_url();?>js/prettify/prettify.js"></script>
 

  <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
  </head>
  
  <body>
 
	  <div class="navbar navbar-fixed-top">
	
			<div class="navbar-inner">
				
				<div class="container">
					
					<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</a>
					
					<a class="brand pull-left" href="./">
						<img style="margin-right:20px" src="<?php echo base_url();?>image/group_logo.png"/>				
					</a>		
					
					<div class="nav-collapse">
						<ul class="nav pull-right">
					
							<li class="dropdown">
								
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" style="margin-top:10px">
									<i class="icon-user"></i> 
									admin									<b class="caret"></b>
								</a>
								
								<ul class="dropdown-menu">
                                                                    <li><a href="<?php echo base_url(); ?>index.php/sms/myaacount">My Profile</a></li>
									<li class="divider"></li>
                                                                        <li><a href="<?php echo base_url();?>index.php/smsmaincontrol/logout">Logout</a></li>
								</ul>
								
							</li>
						</ul>
						
					</div><!--/.nav-collapse -->	
			
				</div> <!-- /container -->
				
			</div> <!-- /navbar-inner -->
			
		</div> <!-- /navbar -->
		
		<!-- Main Content
    ================================================== -->
		<div class="main">

			<div class="main-inner">

			    <div class="container">
			    
			    	<div class="row">
			    	
							<div class="span3 bs-docs-sidebar" style="margin-top:50px; min-height:600px">
								<!-- Secondary vertical navigation
						    ================================================== -->
								<ul class="nav nav-list bs-docs-sidenav">
								  <li class=' sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/login"><img style="margin-right:20px;" src="<?php echo base_url();?>image/glyphicons_041_charts.png"/>Dashboard</a></li>
								  <li class=' active sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/sendsmsnow"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_124_message_plus.png"/>Send Message</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/sendsmslist"><img style="margin-right:25px" src="<?php echo base_url();?>image/glyphicons_123_message_out.png"/>SMS log</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/receiveemail"><img style="margin-right:26px" src="<?php echo base_url();?>image/glyphicons_077_headset.png"/>Email log</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/smsprovider"><img style="margin-right:23px" src="<?php echo base_url();?>image/glyphicons_127_message_flag.png"/>Sms Provider</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/getgroups"><img style="margin-right:18px" src="<?php echo base_url();?>image/glyphicons_024_parents.png"/>Contact Groups</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/alcontacts"><img style="margin-right:19px" src="<?php echo base_url();?>image/glyphicons_024_parents.png"/>All Contacts</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/myaccout"><img style="margin-right:26px" src="<?php echo base_url();?>image/glyphicons_044_keys.png"/>My Account</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/setup"><img style="margin-right:16px" src="<?php echo base_url();?>image/glyphicons_137_cogwheels.png"/>Setup</a></li>
									
								</ul>
								
							</div>
                                    <?php if($_SESSION['msg']=="down"){
                                        
                                     ?>
					  <script type="text/javascript">
						

						toastr.success('Message sent!');
	
							
	
					</script>
                                        <?php }
                                        ?>
<div class="span9" style="margin-top:40px;">
	<h4>Send Message</h4>
	<div class="well well-col well-min">
		
			<h5 class="black">Send SMS For Group</h5>
			
			
			<div class="span5">
			<div class="row-fluid">
                            
			
                            <?php $attributes = array(
                                'class'=>'form-horizontal',
                                'enctype'=>'multipart/form-data'
                                );
                          echo form_open('smsmaincontrol/sendsmsforgroupe',$attributes);?>
				<div class="control-group">
					<label class="control-label" for="messageName">Message</label>
					<div class="controls">
					 <textarea name="messaage_name" value="" class='span9' /></textarea>						</div><!-- /controls -->
				</div><!-- /control-group -->
				<div class="control-group">
					<label class="control-label" for="contactGroup">Choose contact group</label>
					<div class="controls">
																																																																																																																																																																																																																																																																																																							
                                         
<select name="contact_group"  >
                           <?php foreach ($grow as $data1 ) { ?>
                                 <option value="<?php echo $data1; ?>"><?php echo $data1; ?></option><?php
                            
                            }
                            ?>
                            
</select>						
					</div><!-- /controls -->
				</div><!-- /control-group -->
				
				
				<div class="control-group">
					<div class="controls">
						<button type="submit" disabled="disabled" class="btn btn-danger">Send message</button>
					</div><!-- /controls -->
				</div><!-- /control-group -->
			 <?php echo form_close(); ?>
			</div><!-- /row-fluid -->
			</div><!-- /span5 -->
                    <div class="span3">
					</div><!-- /span3 -->
                       
<div class="span5"> <h5 class="black">Send SMS For specific Member</h5>
    <table><tr><td><div class="row-fluid">
			
                            <?php $attributes = array(
                                'class'=>'form-horizontal',
                                'enctype'=>'multipart/form-data'
                                );
                          echo form_open('smsmaincontrol/sendsmsformember',$attributes);?>
                            
                            <div class="control-group">
					<label class="control-label" for="messageName">Message </label>
					<div class="controls">
                                            <textarea name="messaage_name" value="" class='span9' /></textarea>					</div><!-- /controls -->
				</div><!-- /control-group -->
				<div class="control-group">
					<label class="control-label" for="contactGroup">Choose contact Member </label>
					<div class="controls">
																																																																																																																																																																																																																																																																																																							
                                         
<select name="contact_group"  >
                           <?php foreach ($mrow as $data ) { ?>
                                 <option value="<?php echo $data; ?>"><?php echo $data; ?></option><?php
                            
                            }
                            ?>
                            
</select>						
					</div><!-- /controls -->
				</div><!-- /control-group -->
				
				
				<div class="control-group">
					<div class="controls">
                                            <button type="submit" disabled="disabled" class="btn btn-danger">Send message</button>
					</div><!-- /controls -->
				</div><!-- /control-group -->
			</form>
                </div></td><td>
                    <div class="row-fluid">
			
                            <?php $attributes = array(
                                'class'=>'form-horizontal',
                                'enctype'=>'multipart/form-data'
                                );
                          echo form_open('smsmaincontrol/sendsmsfornumber',$attributes);?>
                            
                            <div class="control-group">
					<label class="control-label" for="messageName">Message </label>
					<div class="controls">
                                            <textarea name="messaage_name" value="" class='span9' /></textarea>					</div><!-- /controls -->
				</div><!-- /control-group -->
				<div class="control-group">
					<label class="control-label" for="contactGroup">Enter contact Member </label>
					<div class="controls">
                                            <input type="text" name="contact_group" maxlength="10" n>
						
					</div><!-- /controls -->
				</div><!-- /control-group -->
				
				
				<div class="control-group">
					<div class="controls">
                                            <button type="submit" disabled="disabled" class="btn btn-danger">Send message</button>
					</div><!-- /controls -->
				</div><!-- /control-group -->
			</form>
                </div>
                    
                    
                </td></tr></table><!-- /row-fluid -->
			</div><!-- /span5 -->
	</div><!-- /span9 -->
</div><!-- /well -->				    

			    </div> <!-- /container -->

			</div> <!-- /main-inner -->

  

			<div class="footer-inner">
				
				<div class="container">
					
					<div class="row">
						
		    			<div class="span12">
		    				&copy; Sridhar 2013 <a href="#"></a>.
		    			</div> <!-- /span12 -->
		    			
		    		</div> <!-- /row -->
		    		
				</div> <!-- /container -->
				
			</div> <!-- /footer-inner -->

  </body>
</html>

<?php

}
?>
