<?php  if(!isset($_SESSION['user'])){
    
      redirect('smsmaincontrol/login');
}else{
    
    
    ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>SMS</title>
 

  <!-- Le styles -->
  <link href="<?php echo base_url();?>css/bootstrap.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/style.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/docs.css" rel="stylesheet">
  <link rel='stylesheet' href='<?php echo base_url();?>css/prettify.css' />

	<link rel="stylesheet" href="<?php echo base_url();?>css/fullcalendar.css">
	<link rel="stylesheet" href="<?php echo base_url();?>css/toastr.css">
 
  <script src="<?php echo base_url();?>js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>js/bootstrap.js"></script>
  <script src="<?php echo base_url();?>js/jquery.knob.js"></script>
  <script src="<?php echo base_url();?>js/jquery.sparkline.min.js"></script>
  <script src="<?php echo base_url();?>js/toastr.js"></script>
  <script src="<?php echo base_url();?>js/jquery.tablesorter.min.js"></script>
  <script src="<?php echo base_url();?>js/jquery.peity.min.js"></script>
  <script src="<?php echo base_url();?>js/fullcalendar.min.js"></script>
  <script src="<?php echo base_url();?>js/gcal.js"></script>
  <script src="<?php echo base_url();?>js/prettify/prettify.js"></script>
 

  <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
  </head>
  
  <body>
  
	
 
	  <div class="navbar navbar-fixed-top">
	
			<div class="navbar-inner">
				
				<div class="container">
					
					<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</a>
					
					<a class="brand pull-left" href="./">
						<img style="margin-right:20px" src="<?php echo base_url();?>image/group_logo.png"/>				
					</a>		
					
					<div class="nav-collapse">
						<ul class="nav pull-right">
					
							<li class="dropdown">
								
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" style="margin-top:10px">
									<i class="icon-user"></i> 
									admin									<b class="caret"></b>
								</a>
								
								<ul class="dropdown-menu">
									 <li><a href="<?php echo base_url(); ?>index.php/sms/myaacount">My Profile</a></li>
									<li class="divider"></li>
                                                                        <li><a href="<?php echo base_url();?>index.php/smsmaincontrol/logout">Logout</a></li>
								</ul>
								
							</li>
						</ul>
						
					</div><!--/.nav-collapse -->	
			
				</div> <!-- /container -->
				
			</div> <!-- /navbar-inner -->
			
		</div> <!-- /navbar -->
		
		<!-- Main Content
    ================================================== -->
		<div class="main">

			<div class="main-inner">

			    <div class="container">
			    
			    	<div class="row">
			    	
							<div class="span3 bs-docs-sidebar" style="margin-top:50px; min-height:600px">
								<!-- Secondary vertical navigation
						    ================================================== -->
								<ul class="nav nav-list bs-docs-sidenav">
								  <li class=' sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/login"><img style="margin-right:20px;" src="<?php echo base_url();?>image/glyphicons_041_charts.png"/>Dashboard</a></li>
								  <li class='  sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/sendsmsnow"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_124_message_plus.png"/>Send Message</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/sendsmslist"><img style="margin-right:25px" src="<?php echo base_url();?>image/glyphicons_123_message_out.png"/>SMS log</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/receiveemail"><img style="margin-right:26px" src="<?php echo base_url();?>image/glyphicons_077_headset.png"/>Email log</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/smsprovider"><img style="margin-right:23px" src="<?php echo base_url();?>image/glyphicons_127_message_flag.png"/>Sms Provider</a></li>
								  <li class=' sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/getgroups"><img style="margin-right:18px" src="<?php echo base_url();?>image/glyphicons_024_parents.png"/>Contact Groups</a></li>
								  <li class='active sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/alcontacts"><img style="margin-right:19px" src="<?php echo base_url();?>image/glyphicons_024_parents.png"/>All Contacts</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/myaccout"><img style="margin-right:26px" src="<?php echo base_url();?>image/glyphicons_044_keys.png"/>My Account</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/setup"><img style="margin-right:16px" src="<?php echo base_url();?>image/glyphicons_137_cogwheels.png"/>Setup</a></li>
									
								</ul>
								
							</div>
							
                                    
                                    
                                                                        
                              
                                    
  <script type="text/javascript" charset="utf-8">
      
     
<?php  if($_SESSION['mupdate']=="103") { ?> 
						
                                         toastr.success('Memeber Successfully Updated !');       
 <?php 
        
 } if($_SESSION['mupdate']=="102") {
    ?>                            
 
	toastr.error('This Member is  Already Registered in this group !');
<?php 

} ?>

  
				    				    

		    				  

		$(document).ready(function() {
		
		// Ajax edit contact group
			$(".1").click(function() {
		
			  $.post(''+ $(this).attr('groupid'), function(data) {
				  $('.modal-body').html(data);
				  $("#submitForm").click(function() { 
					  $('#editGroupNameForm').trigger('submit');
					  	$('#editGroup').modal('hide')
					  });
				})	
						
		});
		
		// Ajax Remove contact group
		$(".deletGroup").click(function(e) {
			e.preventDefault();
			$.ajax({
				url: $(this).attr('href'),
				success: function(data) {
					
					if( data.success = true )
					{
						toastr.error('Group deleted!');
						setTimeout(function () {
							window.location.reload();
						}, 1000);
					}
					
				}
			});

		});
		
		});
                
	$(document).ready(function() {
	
		// Pass the id of group to modal
		$(document).on("click", ".open-contact", function () {
		     var groupId = $(this).data('id');
		     var groupName = $(this).data('name');
		     $(".modal-body #GroupID").val( groupId );
		     $(".modal-body #GroupName").val( groupName );
		    $('#addContact').modal('show');
		});
	
		// Ajax add appointment
		
		
		// Ajax add group
				
		
		// Ajax Remove contact
		$(".deleteUser").click(function(e) {
			e.preventDefault();
			$.ajax({
				url: $(this).attr('href'),
				success: function(data) {
					
					if( data.success = true )
					{
						toastr.error('Contact deleted!');
						setTimeout(function () {
							window.location.reload();
						}, 1000);
					}
					
				}
			});

		});
					
				
		});


		
	</script>

		
		
<div class="row">
		    <div class="span9" style="margin-top:40px;">
	<h4>Member</h4>
	<div class="well well-col well-min">
			<div class="row-fluid">
				<h2 class="black">Name  </h2>
				
			</div><!-- /row-fluid -->
			<hr />
			<div class="span4">
			<div class="row-fluid">
				 
                                 <?php
                                
                        foreach ($editrow as $mrow){
                               
                            $attributes = array(
                                
                                'class'=>'form-horizontal',
                                'enctype'=>'multipart/form-data'
                                );echo form_open('sms/editmemberdetails/'.$mrow->id,$attributes);?>
            	<div class="control-group">
				<label class="control-label" for="inputName">Name</label>
				<div class="controls">
					<input type="text" name="name" placeholder="Name" value="<?php echo $mrow->name ?>">
                                        <input type="hidden" name="membergname"  value="<?php echo $mrow->groupname ?>">
				</div><!-- /controls -->
			</div><!-- /control-group -->
			
			<div class="control-group">
				<label class="control-label" for="inputSurname">Number</label>
				<div class="controls">
					<input type="text" name="phone" placeholder="Phone" value="<?php echo $mrow->number ?>">
				</div><!-- /controls -->
			</div><!-- /control-group -->
			
			<div class="control-group">
				<label class="control-label" for="inputEmail">Email</label>
				<div class="controls">
					<input type="text" name="email" placeholder="Email"  value="<?php echo $mrow->email ?>">
				</div><!-- /controls -->
			</div><!-- /control-group -->
			
			
			
			<div class="control-group">
				<label class="control-label" for="inputMobile">Group</label>
				<div class="controls">
                                  <select name="usergroup" value="$rowedit->groupname" >
                           <?php foreach ($row as $data ) {
                           if($mrow->groupname==$data->groupname){?>
                           <option value="<?php echo $data->groupname; ?>"selected="selected" ><?php echo $data->groupname; ?></option>
                            <?php }
                            else{?>
                                 <option value="<?php echo $data->groupname; ?>"><?php echo $data->groupname; ?></option><?php
                            }
                            }
                            ?>
                                  </select>
					
                                        
				</div><!-- /controls -->							
				<div class="clear_10"></div>
			</div><!-- /control-group --><hr />
                        <div class="span2"></div>
                        <div class="span5">
				<button class="btn btn-primary" type="submit">Save changes</button>
                        </div><!-- /span3 --> </form><?php }  echo form_open('sms/memberlist')?>
                        <div class="span4">
				<button class="btn btn-primary" type="submit">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Back&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button>
                        </div><!-- /span3 -->
                       
	
	</div>
	
		
		
	
		</form><!-- /form -->
				</div><!-- /row-fluid -->
			</div><!-- /span4 -->
			
		</div><!-- /well -->
	
	

</div><!-- /span9 -->
				    

			    </div> <!-- /container -->

			</div> <!-- /main-inner -->

  

			<div class="footer-inner">
				
				<div class="container">
					
					<div class="row">
						
		    			<div class="span12">
		    				&copy; Sridhar 2013 <a href="#"></a>.
		    			</div> <!-- /span12 -->
		    			
		    		</div> <!-- /row -->
		    		
				</div> <!-- /container -->
				
			</div> <!-- /footer-inner -->

  </body>
</html>
<?php
}
?>
   