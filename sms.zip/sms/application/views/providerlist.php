<?php  if(!isset($_SESSION['user'])){
    
      redirect('smsmaincontrol/login');
}else{
    
    
    ?>
	
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>SMS</title>
 

  <!-- Le styles -->
  <link href="<?php echo base_url();?>css/bootstrap.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/style.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/docs.css" rel="stylesheet">
  <link rel='stylesheet' href='<?php echo base_url();?>css/prettify.css' />

	<link rel="stylesheet" href="<?php echo base_url();?>css/fullcalendar.css">
	<link rel="stylesheet" href="<?php echo base_url();?>css/toastr.css">
 
  <script src="<?php echo base_url();?>js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>js/bootstrap.js"></script>
  <script src="<?php echo base_url();?>js/jquery.knob.js"></script>
  <script src="<?php echo base_url();?>js/jquery.sparkline.min.js"></script>
  <script src="<?php echo base_url();?>js/toastr.js"></script>
  <script src="<?php echo base_url();?>js/jquery.tablesorter.min.js"></script>
  <script src="<?php echo base_url();?>js/jquery.peity.min.js"></script>
  <script src="<?php echo base_url();?>js/fullcalendar.min.js"></script>
  <script src="<?php echo base_url();?>js/gcal.js"></script>
  <script src="<?php echo base_url();?>js/prettify.js"></script>
 

  <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
  </head>
  
  <body>
  
	   <div class="navbar navbar-fixed-top">
	
			<div class="navbar-inner">
				
				<div class="container">
					
					<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</a>
					
					<a class="brand pull-left" href="./">
						<img style="margin-right:20px" src="<?php echo base_url();?>image/group_logo.png"/>				
					</a>		
					
					<div class="nav-collapse">
						<ul class="nav pull-right">
					
							<li class="dropdown">
								
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" style="margin-top:10px">
									<i class="icon-user"></i> 
									admin									<b class="caret"></b>
								</a>
								
								<ul class="dropdown-menu">
									 <li><a href="<?php echo base_url(); ?>index.php/sms/myaacount">My Profile</a></li>
									<li class="divider"></li>
                                                                        <li><a href="<?php echo base_url();?>index.php/smsmaincontrol/logout">Logout</a></li>
								</ul>
								
							</li>
						</ul>
						
					</div><!--/.nav-collapse -->	
			
				</div> <!-- /container -->
				
			</div> <!-- /navbar-inner -->
			
		</div> <!-- /navbar -->
		
		<!-- Main Content
    ================================================== -->
		<div class="main">

			<div class="main-inner">

			    <div class="container">
			    
			    	<div class="row">
			    	
							<div class="span3 bs-docs-sidebar" style="margin-top:50px; min-height:600px">
								<!-- Secondary vertical navigation
						    ================================================== -->
								<ul class="nav nav-list bs-docs-sidenav">
								  <li class=' sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/login"><img style="margin-right:20px;" src="<?php echo base_url();?>image/glyphicons_041_charts.png"/>Dashboard</a></li>
								  <li class=' sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/sendsmsnow"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_124_message_plus.png"/>Send Message</a></li>
								  <li class='  sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/sendsmslist"><img style="margin-right:25px" src="<?php echo base_url();?>image/glyphicons_123_message_out.png"/>SMS log</a></li>
								  <li class='  sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/receiveemail"><img style="margin-right:26px" src="<?php echo base_url();?>image/glyphicons_077_headset.png"/>Email log</a></li>
								  <li class='active sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/smsprovider"><img style="margin-right:23px" src="<?php echo base_url();?>image/glyphicons_127_message_flag.png"/>Sms Provider</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/getgroups"><img style="margin-right:18px" src="<?php echo base_url();?>image/glyphicons_024_parents.png"/>Contact Groups</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/alcontacts"><img style="margin-right:19px" src="<?php echo base_url();?>image/glyphicons_024_parents.png"/>All Contacts</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/myaccout"><img style="margin-right:26px" src="<?php echo base_url();?>image/glyphicons_044_keys.png"/>My Account</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/setup"><img style="margin-right:16px" src="<?php echo base_url();?>image/glyphicons_137_cogwheels.png"/>Setup</a></li>
									
								</ul>
								
							</div>
                                   
                                  
                                        

							<div class="span9" style="margin-top:40px">
								
								<div class="row">
									<div class="span9">
										<h4>SMS providers</h4>
									</div>
									<div class="span3" style="display:">
										<div class="well well-col" align="center">
											<a href="<?php echo base_url();?>index.php/smsmaincontrol/addnewprovider" role="button" class="btn btn-danger"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_129_message_new.png"/>Add New provider</a>
										</div><!-- /well -->
									</div><!-- /span3 -->
									
									
					
								</div><!-- /row -->
								
							</div><!-- /row -->
							
							<div class="row">

									<div class="span9">
										<div class="well well-col">
									
																				<div class='row-fluid'>
						<a class='btn btn-danger' style='display:none' href='-1'>← Newer</a>
						<p><?php echo $links; ?></p></div><div class='row-fluid'>
							<span class='log-text pull-left'>Total SMS Provider:&nbsp;&nbsp; <?php echo $count; ?></span>
							<span class='log-text pull-right'>Page number: 0</span>
						</div><table class='table table-striped'>
							<thead>
								<tr>
									<th></th>
									<th width='50%'>Login Url</th>
									<th width='18%'>Username</th>
                                                                        <th width='25%' >Password</th>
									
									
									
								</tr>
							</thead>
							<tbody><?php 
                                                            if($_SESSION['smsprovider']=='null'){
                                                                
                                                            }else{
                                                            ?>
                                                            <?php foreach ($row as $data ) { ?>
                                                          <tr class='bg-trans'>
							<td><i class='icon-envelope'></i></td>
							<td><?php echo $data->loginref  ?></td>
							<td><?php echo $data->username ?></td>
							<td><?php echo $data->password ?>!</td>
							
                                                        <td>
								<div class="btn-group">
									<a class="btn btn-default" href="#">
										<i class="icon-user"></i>
										
									</a>
									<a class="btn btn-default dropdown-toggle" href="#" data-toggle="dropdown">
										<span class="caret"></span>
									</a>
									<ul class="dropdown-menu">
										<li><a class='' href="<?php echo base_url();?>index.php/sms/editsmsprovider/<?php echo $data->id ?>"><i class="icon-pencil"></i>Edit</a></li>
										<li class="divider"></li>
										<li><a class='deleteUser' href="<?php echo base_url();?>index.php/sms/deletesmsprovider/<?php echo $data->id ?>""><i class="icon-pencil"></i>Delete</a></li>
										
										<li><a href="#"></li>
									</ul>
								</div><!-- /btn-group -->
								</td>
							
							</tr>
                                                        <?php }}?></tbody>
					</table>										
										</div>		
									</div>
								</div>
							</div>
				    </div>
			    </div> <!-- /container -->

			</div> <!-- /main-inner -->

  

			<div class="footer-inner">
				
				<div class="container">
					
					<div class="row">
						
		    			<div class="span12">
		    				&copy;Sridhar 2013 <a href="#"></a>.
		    			</div> <!-- /span12 -->
		    			
		    		</div> <!-- /row -->
		    		
				</div> <!-- /container -->
				
			</div> <!-- /footer-inner -->

  </body>
</html>

 <?php
}
?>
