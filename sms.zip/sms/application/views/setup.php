<?php  if(!isset($_SESSION['user'])){
    
      redirect('smsmaincontrol/login');
}else{
    
    
    ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>SMS</title>
 

  <!-- Le styles -->
  <link href="<?php echo base_url();?>css/bootstrap.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/style.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/docs.css" rel="stylesheet">
  <link rel='stylesheet' href='<?php echo base_url();?>css/prettify.css' />

	<link rel="stylesheet" href="<?php echo base_url();?>css/fullcalendar.css">
	<link rel="stylesheet" href="<?php echo base_url();?>css/toastr.css">
 
  <script src="<?php echo base_url();?>js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>js/bootstrap.js"></script>
  <script src="<?php echo base_url();?>js/jquery.knob.js"></script>
  <script src="<?php echo base_url();?>js/jquery.sparkline.min.js"></script>
  <script src="<?php echo base_url();?>js/toastr.js"></script>
  <script src="<?php echo base_url();?>js/jquery.tablesorter.min.js"></script>
  <script src="<?php echo base_url();?>js/jquery.peity.min.js"></script>
  <script src="<?php echo base_url();?>js/fullcalendar.min.js"></script>
  <script src="<?php echo base_url();?>js/gcal.js"></script>
  <script src="<?php echo base_url();?>js/prettify/prettify.js"></script>
 

  <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
  </head>
  
  <body>
  
	
 
	  <div class="navbar navbar-fixed-top">
	
			<div class="navbar-inner">
				
				<div class="container">
					
					<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</a>
					
					<a class="brand pull-left" href="./">
						<img style="margin-right:20px" src="<?php echo base_url();?>image/group_logo.png"/>				
					</a>		
					
					<div class="nav-collapse">
						<ul class="nav pull-right">
					
							<li class="dropdown">
								
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" style="margin-top:10px">
									<i class="icon-user"></i> 
									admin									<b class="caret"></b>
								</a>
								
								<ul class="dropdown-menu">
									 <li><a href="<?php echo base_url(); ?>index.php/sms/myaacount">My Profile</a></li>
									<li class="divider"></li>
                                                                        <li><a href="<?php echo base_url();?>index.php/smsmaincontrol/logout">Logout</a></li>
								</ul>
								
							</li>
						</ul>
						
					</div><!--/.nav-collapse -->	
			
				</div> <!-- /container -->
				
			</div> <!-- /navbar-inner -->
			
		</div> <!-- /navbar -->
		
		<!-- Main Content
    ================================================== -->
		<div class="main">

			<div class="main-inner">

			    <div class="container">
			    
			    	<div class="row">
			    	
							<div class="span3 bs-docs-sidebar" style="margin-top:50px; min-height:600px">
								<!-- Secondary vertical navigation
						    ================================================== -->
								<ul class="nav nav-list bs-docs-sidenav">
								  <li class=' sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/login"><img style="margin-right:20px;" src="<?php echo base_url();?>image/glyphicons_041_charts.png"/>Dashboard</a></li>
								  <li class='  sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/sendsmsnow"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_124_message_plus.png"/>Send Message</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/sendsmslist"><img style="margin-right:25px" src="<?php echo base_url();?>image/glyphicons_123_message_out.png"/>SMS log</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/receiveemail"><img style="margin-right:26px" src="<?php echo base_url();?>image/glyphicons_077_headset.png"/>Email log</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/smsprovider"><img style="margin-right:23px" src="<?php echo base_url();?>image/glyphicons_127_message_flag.png"/>Sms Provider</a></li>
								  <li class=' sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/getgroups"><img style="margin-right:18px" src="<?php echo base_url();?>image/glyphicons_024_parents.png"/>Contact Groups</a></li>
								  <li class=' sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/alcontacts"><img style="margin-right:19px" src="<?php echo base_url();?>image/glyphicons_024_parents.png"/>All Contacts</a></li>
								  <li class=' sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/myaccout"><img style="margin-right:26px" src="<?php echo base_url();?>image/glyphicons_044_keys.png"/>My Account</a></li>
								  <li class='active sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/setup"><img style="margin-right:16px" src="<?php echo base_url();?>image/glyphicons_137_cogwheels.png"/>Setup</a></li>
									
								</ul>
								
							</div>
							
                                    
                                    
                                                                        
                              

				    				    <script type="text/javascript" charset="utf-8">

	$(function() { 
		
		//Update account details
		$("#twilio_form").submit(function() {
			$.ajax({
				
				url: $(this).attr('action'),
				type: "POST",
				dataType: 'json',
				data: $("#twilio_form").serialize(),
				success: function(data) {
					
					if( data.success = true )
					{
						toastr.success('Account details updated!');
					}
					if( data.errors != undefined )
					{
						alert(data.errors);
					}
					
				}
				
			});
			
			return false;
			
		});
		
		});
		
</script>

		<div class="span8" style="margin-top:40px">
			
				<h4>Site settings</h4>
				<p style="color:#37b1ff; font-size:20px"></p>
					<div class="well-min-set">
							<script>
	$(document).ready(function() {      
	   	// Pause slider
	   	$('.carousel').carousel('pause');
	   	
	   	// Settings btn navigation
			$("#btn-intro").click(function() {
				$('.carousel').carousel(0);
			});
			
			$("#btn-twilio").click(function() {
				$('.carousel').carousel(1);
			});
			
			$("#btn-help").click(function() {
				$('.carousel').carousel(2);
			});
		
		// Hold slider
		$('.carousel').carousel('pause');
	});
	
	
</script>

	<div id="myCarousel" class="carousel slide well well-col well-min">
		<div class="carousel-inner">
		
			<div class="item active none-min-set">
					<div class="span7">
						<div class="none">
							<h3 class="black">Sridhar SMS</h3>
							<p></p>
							<ol>    <li>Host Sridhar SMS  </li>
                                                                <li>Set An email As an Admin The username and password are same  </li>
                                                                
								<li>Set Any sms Provider </li>
								<li>Add Your Contact Group And Contact </li>
								<li>Sned Mail to Admin With Your Contact It will send to Your contacts </li>
                                                                <li>Your Email subject should specific Groupname or contact Number </li>
								<br/>
								
							</ol>
						</div><!-- /none -->
						
					</div><!-- /controls -->
					
			</div>
			<div class="item none-min-set">
				<script type="text/javascript" charset="utf-8">

	$(function() { 
		
		//Input Twilio account details to db
		$("#twilio_form").submit(function() {
			$.ajax({
				
				url: $(this).attr('action'),
				type: "POST",
				dataType: 'json',
				data: $("#twilio_form").serialize(),
				success: function(data) {
					
					if( data.success = true )
					{
						// Popup alert
						toastr.success('Twilio account details entered!');
						setTimeout(function () {
						  $('.carousel').carousel(2)
						}, 3000);
					}
					if( data.errors != undefined )
					{
						alert(data.errors);
					}
					
				}
				
			});
			
			return false;
			
		});
		
		});
		
</script>
<div class="span7">
	<div class="none">
		<h3 class="black">Setup Of Sridhar Sms</h3>
		<ol>
								<li>Select any sms provider site and create an account </li>
								<li>copy the login page url and reference page Url of the sms provider </li>
								<li>Before login just press CTRL+U Keys on your keyboard for See the login page source </li>
                                                                <li>Then copy the Username Textbox-Name,PasswordBox-Name,LoginButton-Name and LoginButton-Value  </li>
                                                                <li>Then Login to the Your Sms Provider</li>
                                                                <li>After login Copy the Home page url And Send message Page Url</li>
                                                                <li>Again go to page source for the message page  </li>
                                                                <li>Here copy the ContactNumberBox-Name,MessageBox-name and SendButton Name and Value </li>
                                                                <li>At Last Paste All Details In Sridhar SmS </li>
								<br/>
								
							</ol>
		<br />
		<p> This Application is fully free </p>
		
	
	</div><!-- /none -->
</div><!-- /span7 -->			</div><!-- /item -->
			<div class="item none-min-set">
				<div class="span7">
	<div class="none">
		<h3 class="black">Help</h3>
		<p> Just Send an email to sridharkalaibala@gmail.com
				
		</p>
	</div><!-- /none -->
</div><!-- /span7 -->			</div><!-- /item -->
		</div><!-- /item active -->
		<a class="left carousel-control" data-slide="prev" href="#myCarousel" style="display:none">‹</a>
		<a class="right carousel-control" data-slide="next" href="#myCarousel" style="display:none">›</a>
		<button id="btn-intro" class="btn btn-default btn-large set-btn"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_242_google_maps.png"/>Intro</button>
		<button id="btn-twilio" class="btn btn-default btn-large set-btn"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_136_cogwheel.png"/>Setup</button>
		<button id="btn-help" class="btn btn-default btn-large set-btn"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_195_circle_info.png"/>Help</button>
	</div><!-- /carousel -->					</div><!-- /well -->
				</div><!-- /span8 -->
		</div>				    

			    </div> <!-- /container -->

			</div> <!-- /main-inner -->

  

			<div class="footer-inner">
				
				<div class="container">
					
					<div class="row">
						
		    			<div class="span12">

		    				&copy; Sridhar 2013 <a href="#"></a>.
		    			</div> <!-- /span12 -->
		    			
		    		</div> <!-- /row -->
		    		
				</div> <!-- /container -->
				
			</div> <!-- /footer-inner -->

  </body>
</html>
<?php
}
?>
   