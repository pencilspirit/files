<?php  if(!isset($_SESSION['user'])){
    
      redirect('smsmaincontrol/login');
}else{
    
    
    ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>SMS</title>
 

  <!-- Le styles -->
  <link href="<?php echo base_url();?>css/bootstrap.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/style.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/docs.css" rel="stylesheet">
  <link rel='stylesheet' href='<?php echo base_url();?>css/prettify.css' />

	<link rel="stylesheet" href="<?php echo base_url();?>css/fullcalendar.css">
	<link rel="stylesheet" href="<?php echo base_url();?>css/toastr.css">
 
  <script src="<?php echo base_url();?>js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>js/bootstrap.js"></script>
  <script src="<?php echo base_url();?>js/jquery.knob.js"></script>
  <script src="<?php echo base_url();?>js/jquery.sparkline.min.js"></script>
  <script src="<?php echo base_url();?>js/toastr.js"></script>
  <script src="<?php echo base_url();?>js/jquery.tablesorter.min.js"></script>
  <script src="<?php echo base_url();?>js/jquery.peity.min.js"></script>
  <script src="<?php echo base_url();?>js/fullcalendar.min.js"></script>
  <script src="<?php echo base_url();?>js/gcal.js"></script>
  <script src="<?php echo base_url();?>js/prettify/prettify.js"></script>
 

  <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
  </head>
  
  <body>
  
	
 
	  <div class="navbar navbar-fixed-top">
	
			<div class="navbar-inner">
				
				<div class="container">
					
					<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</a>
					
					<a class="brand pull-left" href="./">
						<img style="margin-right:20px" src="<?php echo base_url();?>image/group_logo.png"/>				
					</a>		
					
					<div class="nav-collapse">
						<ul class="nav pull-right">
					
							<li class="dropdown">
								
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" style="margin-top:10px">
									<i class="icon-user"></i> 
									admin									<b class="caret"></b>
								</a>
								
								<ul class="dropdown-menu">
									 <li><a href="<?php echo base_url(); ?>index.php/sms/myaacount">My Profile</a></li>
									<li class="divider"></li>
                                                                        <li><a href="<?php echo base_url();?>index.php/smsmaincontrol/logout">Logout</a></li>
								</ul>
								
							</li>
						</ul>
						
					</div><!--/.nav-collapse -->	
			
				</div> <!-- /container -->
				
			</div> <!-- /navbar-inner -->
			
		</div> <!-- /navbar -->
		
		<!-- Main Content
    ================================================== -->
		<div class="main">

			<div class="main-inner">

			    <div class="container">
			    
			    	<div class="row">
			    	
							<div class="span3 bs-docs-sidebar" style="margin-top:50px; min-height:600px">
								<!-- Secondary vertical navigation
						    ================================================== -->
								<ul class="nav nav-list bs-docs-sidenav">
								  <li class=' sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/login"><img style="margin-right:20px;" src="<?php echo base_url();?>image/glyphicons_041_charts.png"/>Dashboard</a></li>
								  <li class='  sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/sendsmsnow"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_124_message_plus.png"/>Send Message</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/sendsmslist"><img style="margin-right:25px" src="<?php echo base_url();?>image/glyphicons_123_message_out.png"/>SMS log</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/receiveemail"><img style="margin-right:26px" src="<?php echo base_url();?>image/glyphicons_077_headset.png"/>Email log</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/smsprovider"><img style="margin-right:23px" src="<?php echo base_url();?>image/glyphicons_127_message_flag.png"/>Sms Provider</a></li>
								  <li class='active sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/getgroups"><img style="margin-right:18px" src="<?php echo base_url();?>image/glyphicons_024_parents.png"/>Contact Groups</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/alcontacts"><img style="margin-right:19px" src="<?php echo base_url();?>image/glyphicons_024_parents.png"/>All Contacts</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/myaccout"><img style="margin-right:26px" src="<?php echo base_url();?>image/glyphicons_044_keys.png"/>My Account</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/setup"><img style="margin-right:16px" src="<?php echo base_url();?>image/glyphicons_137_cogwheels.png"/>Setup</a></li>
									
								</ul>
								
							</div>
							
                                    
                                    
                                                                        
                              
                                    
  <script type="text/javascript" charset="utf-8">
      <?php if( $_SESSION['medelete']=="deleteed"){?>
          toastr.error('The Group Is Successfully Deleted!');
          <?php }
          ?>
      
<?php if($_SESSION['Ge']=='Sridhar') { ?> 
						toastr.success('Group Is Successfully Edited !');
                                                
 <?php 

 } if($_SESSION['Ge']=='already') {
    ?>                            
 
	toastr.error('This Group is Already Registered !');
<?php 

} ?>
  <?php if($_SESSION['Ge']=='error') 
      {
     
      ?>                            
toastr.error('Please Enter the Correct Details!');

<?php } ?>
    
    
    
    
    <?php if( $_SESSION['groupundo']=="dow") { ?> 
						toastr.success('New Group Is Successfully Added !');
                                                
 <?php 

 } if( $_SESSION['groupundo']=="sasi") {
    ?>                            
 
	toastr.error('This Group is Already Registered !');
<?php 

} ?>
  
				    				    

		    				  

		$(document).ready(function() {
		
		// Ajax edit contact group
			$(".1").click(function() {
		
			  $.post(''+ $(this).attr('groupid'), function(data) {
				  $('.modal-body').html(data);
				  $("#submitForm").click(function() { 
					  $('#editGroupNameForm').trigger('submit');
					  	$('#editGroup').modal('hide')
					  });
				})	
						
		});
		
		// Ajax Remove contact group
		$(".deletGroup").click(function(e) {
			e.preventDefault();
			$.ajax({
				url: $(this).attr('href'),
				success: function(data) {
					
					if( data.success = true )
					{
						toastr.error('Group deleted!');
						setTimeout(function () {
							window.location.reload();
						}, 1000);
					}
					
				}
			});

		});
		
		});
                
	$(document).ready(function() {
	
		// Pass the id of group to modal
		$(document).on("click", ".open-contact", function () {
		     var groupId = $(this).data('id');
		     var groupName = $(this).data('name');
		     $(".modal-body #GroupID").val( groupId );
		     $(".modal-body #GroupName").val( groupName );
		    $('#addContact').modal('show');
		});
	
		// Ajax add appointment
		
		
		// Ajax add group
				
		
		// Ajax Remove contact
		$(".deleteUser").click(function(e) {
			e.preventDefault();
			$.ajax({
				url: $(this).attr('href'),
				success: function(data) {
					
					if( data.success = true )
					{
						toastr.error('Contact deleted!');
						setTimeout(function () {
							window.location.reload();
						}, 1000);
					}
					
				}
			});

		});
					
				
		});


		
	</script>

		<div class="span9" style="margin-top:40px">
			
			<div class="row">
				<div class="span9">
					<h4>Groups</h4>
				</div>
				<div class="span3">
					<div class="well well-col" align="center">
						<a href="#addGroup" role="button" data-toggle="modal" class="btn btn-danger"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_043_group_22h.png"/>New Group</a>
					</div><!-- /well -->
				</div><!-- /span3 -->
				
				<div class="span3">
					<div class="well well-col" align="center">
						<a href="<?php echo base_url();?>index.php/sms/datagroupsetting" role="button" class="btn btn-danger"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_043_group_22h.png"/>Manage Groups</a>
					</div><!-- /well -->
				</div><!-- /span3 -->
				
				<div class="span3">
					<div class="well well-col" style="min-height:33px" align="center">
<a href="<?php echo base_url();?>index.php/sms/memberlist" role="button" class="btn btn-danger"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_043_group_22h.png"/>Manage Members</a>
				
					</div><!-- /well -->
				</div><!-- /span3 -->

			</div><!-- /row -->
			
		</div><!-- /row -->
		
<div class="row">
	<div style="margin-left:200px">
		<p><?php echo $links; ?></div>
		
		
				<div class="span8 well well-col">
					<table class="table table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Name</th>
								<th>Members</th>
								<th>Edit</th>
							</tr>
						</thead>
						<tbody>
								<?php if($_SESSION['nogroup']=='null'){
                                                                
                                                                }  else {
                                                                    
                                                                
                                                                $no=0;
                                                                foreach ($row as $grow){
                                                                    $me=0;
                                                                    foreach ($mrow as $member){
                                                                        if($member->groupname==$grow->groupname){
                                                                            $me++;
                                                                        }
                                                                    }
                                                                    ?>							
							<tr class="bg-trans">
								<td><?php echo $no+1;?></td>
								<td><?php echo $grow->groupname ?></td>
								<td><?php echo $me; ?></td>
								<td>
								<div class="btn-group">
									<a class="btn btn-default" href="#">
										<i class="icon-user"></i>
										
									</a>
									<a class="btn btn-default dropdown-toggle" href="#" data-toggle="dropdown">
										<span class="caret"></span>
									</a>
									<ul class="dropdown-menu">
										<li><a data-toggle="modal" data-id="33" data-name="<?php echo $grow->groupname ?>" title="Add this item" class="open-contact  btn-small" href="#addContact">Edit group</a></li>
										
										<li><a data-toggle="" data-id="33" data-name="<?php echo $grow->groupname ?>"  title="Add this item" class="" href="<?php echo base_url();?>index.php/sms/groupdelete/<?php echo $grow->groupname ?> ">Delete group</a></li>
										
                                                                             
										<li><a href="#"></li>
									</ul>
								</div><!-- /btn-group -->
								</td>
							</tr>
                                                        <?php $no++;
                                                        
                                                        }
                                                        
                                                        } ?>
							
                        
																				</tbody>
					</table>
				</div><!-- /span8 -->
			</div><!-- /row -->
		
</div><!-- /span9 -->
 
<!-- Modal -->
<!-- Modal -->
<div id="editGroup" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		<h3 class="black">Edit Group</h3>
	</div><!-- /modal-header -->
	<div class="modal-body">
	</div><!-- /modal-body -->
	<div class="modal-footer">
		<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
		<button id="submitForm" class="btn btn-primary" type="submit">Save changes</button>
	</div><!-- /modal-footer -->
</div><!-- /modal -->	
<!-- Modal -->
<div id="addContact" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		<h3 id="myModalLabel" class="black">Edit Group</h3>
	</div><!-- /modal-header -->
	<div class="modal-body text-grey">
            <?php $attributes = array(
                                
                                'class'=>'form-horizontal',
                                'enctype'=>'multipart/form-data'
                                );echo form_open('sms/editgroup',$attributes)
                                         ?>
            	
			
			
			
			
			
			<div class="control-group">
				<label class="control-label" for="inputMobile">Group</label>
				<div class="controls">
					<input type="text" name="groupName" id="GroupName" value="" >
                                        <input type="hidden" name="groupNamed" id="GroupName" value="">
					
                                        
				</div><!-- /controls -->							
				<div class="clear_10"></div>
			</div><!-- /control-group -->
	
	</div>
	<div class="modal-footer">
		<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
		<button class="btn btn-primary" type="submit">Save changes</button>
	</div><!-- /modal-footer -->
		</form><!-- /form -->
      
</div><!-- /modal -->

<!-- Modal -->
<div id="addGroup" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		<h3 id="myModalLabel" class="black">New Group</h3>
	</div>
	<div class="modal-body text-grey">
		 <?php $attributes = array(
                                
                                'class'=>'form-horizontal',
                                'enctype'=>'multipart/form-data'
                                );echo form_open('sms/addnewgroup',$attributes)?>
			<div class="control-group">
				<label class="control-label" for="inputName">Group description</label>
				<div class="controls">
					<input type="text" name="name" placeholder="name" value="">
				</div><!-- /controls -->
			</div><!-- /control-group -->
			
	</div>
	<div class="modal-footer">
		<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
		<button class="btn btn-primary" type="submit">Save changes</button>
	</div><!-- /modal-footer -->
		</form><!-- /form -->
</div><!-- /modal -->				    

			    </div> <!-- /container -->

			</div> <!-- /main-inner -->

  

			<div class="footer-inner">
				
				<div class="container">
					
					<div class="row">
						
		    			<div class="span12">
		    				&copy; Sridhar 2013 <a href="#"></a>.
		    			</div> <!-- /span12 -->
		    				</div> <!-- /row -->
		    		
				</div> <!-- /container -->
				
			</div> <!-- /footer-inner -->

  </body>
</html>

<?php
}
?>