<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Sms extends CI_Controller {

   function __construct()
   {
     
      parent::__construct();
     session_start();
   }
   function index()
   {
           
   }
   function datagroupsetting(){
       $_SESSION['Ge']='null';
       $_SESSION['groupundo']='null';
       $_SESSION['medelete']="null";
             $this->load->helper("url");
             $this->load->model("groupmodel");
             $this->load->library("pagination");
        
	        $config["base_url"] = base_url().'index.php/sms/datagroupsetting';
	        $config["total_rows"] = $this->groupmodel->record_count();
	        $config["per_page"] = 7;
	        $config["uri_segment"] = 3;
                $config['full_tag_open']='<div id="pagination" >';
                $config['full_tag_close']='</div>';
	 
	        $this->pagination->initialize($config);
	 
	        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $data['count']=$this->groupmodel->record_count();
                if($data['count']==0){
                    $_SESSION['nogroup']='null';
                }
                else{
                     $_SESSION['nogroup']='hai';
                }
	        $data["row"] = $this->groupmodel->fetch_countries($config["per_page"], $page);
	        $data["links"] = $this->pagination->create_links();
       
       
       
       
       $this->load->model('groupmodel');
           
           $data['mrow']=  $this->groupmodel->getmemberlist();
           $this->load->view('grouplist',$data);
   }
   public function editgroup()
   {
       $_SESSION['Ge']='null';
        $_SESSION['medelete']="null";
         $_SESSION['groupundo']='null';
       $this->load->library('form_validation');
	
      $this->form_validation->set_rules("groupName","GroupName","required"); 
         if ( $this->form_validation->run() !== false ) {
			  $this->load->model('groupmodel');
                          $gname=$this->input->post('groupName');
                          $orgial=$this->input->post('groupNamed');
                            if($this->groupmodel->checkgroupforedit($gname,$orgial)){
                             $_SESSION['Ge']='already';
                             $this->afterdatagroupsetting();
                             
                          }  else {
                              $this->groupmodel->groupedit($gname,$orgial);
                               $_SESSION['Ge']='Sridhar';
                                $this->afterdatagroupsetting();
         }
   }else{
         $_SESSION['Ge']='error';
          $this->afterdatagroupsetting();
   }
   }

   
   function delete($id)
   
   {
       $_SESSION['Ge']='null';
       $_SESSION['medelete']="null";
       $_SESSION['groupundo']='null';
       $this->load->model('group')      ;
       $this->group->delete($id);
          
       $data['row']= $this->group->getgroup();
       $this->load->view('group',$data);
   }
   function afterdatagroupsetting(){
       
             $this->load->helper("url");
             $this->load->model("groupmodel");
             $this->load->library("pagination");
        
	        $config["base_url"] = base_url().'index.php/sms/datagroupsetting';
	        $config["total_rows"] = $this->groupmodel->record_count();
	        $config["per_page"] = 7;
	        $config["uri_segment"] = 3;
                $config['full_tag_open']='<div id="pagination" >';
                $config['full_tag_close']='</div>';
	 
	        $this->pagination->initialize($config);
	 
	        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $data['count']=$this->groupmodel->record_count();
	        $data["row"] = $this->groupmodel->fetch_countries($config["per_page"], $page);
	        $data["links"] = $this->pagination->create_links();
       
       
       
       
       $this->load->model('groupmodel');
           
           $data['mrow']=  $this->groupmodel->getmemberlist();
           $this->load->view('grouplist',$data);
   }
   
    public function addnewgroup(){
          $_SESSION['addmember']="null";
         $_SESSION['Ge']='null';
          $_SESSION['medelete']="null";
       if(!isset($_SESSION['user'])){
                   
           $this->login();
          
       }else{
            $this->load->library('form_validation');
	
      $this->form_validation->set_rules("name","Name","required"); 
      
      
	  
	    if ( $this->form_validation->run() !== false ) {
                
			  $this->load->model('groupmodel');
                          $name=$this->input->post('name');
                          if($this->groupmodel->checkgroup($name)){
                              $_SESSION['groupundo']='sasi';
                              $this->afterdatagroupsetting();
                          }  else {
                              
                          $this->groupmodel->addgroup($name);
                           $_SESSION['groupundo']='dow';
                           $this->afterdatagroupsetting();
                              
                          }
                           
       }  else {
             $_SESSION['groupundo']='null';
            $this->afterdatagroupsetting();
       }
       
   }
   }
   function memberlist(){
       
       $_SESSION['delete']="null";
        $this->load->helper("url");
        $_SESSION['nodata']='down';
             $this->load->model("groupmodel");
             $this->load->library("pagination");
        
	        $config["base_url"] = base_url().'index.php/sms/memberlist';
	        $config["total_rows"] = $this->groupmodel->memberrecord_count();
	        $config["per_page"] = 7;
	        $config["uri_segment"] = 3;
                $config['full_tag_open']='<div id="pagination" >';
                $config['full_tag_close']='</div>';
	 
	        $this->pagination->initialize($config);
	 
	        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $data['count']=$this->groupmodel->memberrecord_count();
                if($data['count']==0){
                   $_SESSION['nodata']="nope";
                }
	        $data["row"] = $this->groupmodel->fetch_member($config["per_page"], $page);
	        $data["links"] = $this->pagination->create_links();
                $this->load->model('groupmodel');           
                $data['mrow']=  $this->groupmodel->getmemberlist();       
                $this->load->view('allmembers',$data);
       
   }
    function memberlisted(){
       
       
        $this->load->helper("url");
             $this->load->model("groupmodel");
             $this->load->library("pagination");
        $_SESSION['nodata']='down';
	        $config["base_url"] = base_url().'index.php/sms/memberlist';
	        $config["total_rows"] = $this->groupmodel->memberrecord_count();
	        $config["per_page"] = 7;
	        $config["uri_segment"] = 3;
                $config['full_tag_open']='<div id="pagination" >';
                $config['full_tag_close']='</div>';
	 
	        $this->pagination->initialize($config);
	 
	        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $data['count']=$this->groupmodel->memberrecord_count();
                 if($data['count']==0){
                   $_SESSION['nodata']="nope";
                }
	        $data["row"] = $this->groupmodel->fetch_member($config["per_page"], $page);
	        $data["links"] = $this->pagination->create_links();
                $this->load->model('groupmodel');           
                      
                $this->load->view('allmembers',$data);
       
   }
   function memberedit($id){
       
       $_SESSION['mupdate']='null';
      
          $this->load->model('smsmember')      ;
      
            $data['editrow']= $this->smsmember->editmember($id);
         $this->load->model('group')      ;
         $data['row']= $this->group->getgroup();
         $this->load->view('memberedit',$data);
   }
   function aftermemberedit($id){
       
     
      
          $this->load->model('smsmember')      ;
      
            $data['editrow']= $this->smsmember->editmember($id);
         $this->load->model('group')      ;
         $data['row']= $this->group->getgroup();
         $this->load->view('memberedit',$data);
   }
   function editmemberdetails($id){
      
       
        $this->load->library('form_validation');
	
      $this->form_validation->set_rules("name","Name","required"); 
      $this->form_validation->set_rules('phone', 'Phone', 'required|regex_match[/^[0-9]+$/]|xss_clean');
    
      $this->form_validation->set_rules("usergroup","Usergroup","required"); 
      $this->form_validation->set_rules('email', 'Email', 'valid_email|required');
      
	  
	    if ( $this->form_validation->run() !== false ) {
			  $this->load->model('groupmodel');
                          $name=$this->input->post('name');
			$phone=$this->input->post('phone');
			$email=$this->input->post('email');
			$usergroup=$this->input->post('usergroup');
                        $orgibal=$this->input->post('membergname');
                        $satus=$this->groupmodel->groupedited($id,$usergroup,$email);
                        if($satus!=TRUE){
                            
                            $this->groupmodel->updatedata($id,$name,$email,$usergroup,$phone);
                         $_SESSION['mupdate']='103';
                         $this->aftermemberedit($id);
                        }else{
                             $_SESSION['mupdate']='102';
                             $this->aftermemberedit($id);
                        }
            }else{
                $this->aftermemberedit($id);
            }
   }
   function memberdelete($id){
        $this->load->model('groupmodel');
         $satus=$this->groupmodel->deletemember($id);
        $_SESSION['delete']="deleteed";
        redirect('sms/memberlisted');
   }
   function groupdelete($id){
        $this->load->model('groupmodel');
         $satus=$this->groupmodel->deletegroup($id);
         $_SESSION['Ge']='null';
        $_SESSION['medelete']="null";
         $_SESSION['groupundo']='null';
          $_SESSION['medelete']="deleteed";
          redirect('sms/afterdatagroupsetting');
         
   }
   public function myaacount(){
       $this->load->model('groupmodel');
    
       
       $data['row']=$this->groupmodel->getuser();
       $this->load->view('profile',$data);
   }
   function editprofile()
   {
         $this->load->library('form_validation');
      $this->form_validation->set_rules("password","Password","required"); 
	    $this->form_validation->set_rules("username","username","required"); 
		  $this->form_validation->set_rules("userpass","userpass","required"); 
      $this->form_validation->set_rules('email', 'Email', 'valid_email|required');
       $this->form_validation->set_rules('useremail', 'Useremail', 'valid_email|required');
     
      
	  
	    if ( $this->form_validation->run() !== false ) {
			  $this->load->model('groupmodel');
                        $email=$this->input->post('email');
						$pass=$this->input->post('password');
						$username=$this->input->post('username');
						$userpass=$this->input->post('userpass');
                        $useremail=$this->input->post('useremail');
                        $this->groupmodel->updateuser($email,$pass,$useremail,$username,$userpass);
                        $data['row']=$this->groupmodel->getuser();
                        $this->load->view('profile',$data);
   }else{
       $this->myaacount();
   }
   }
   public function setup(){
       $this->load->view('setup');
   }
   function editsmsprovider($id){
       $this->load->model('smsproviders');
       $_SESSION['code']='unset';
       $data['prow']=  $this->smsproviders->getsmsprovider($id);
       $this->load->view('smsprovideredit',$data);
   }
    function editsmsprovidered($id){
       $this->load->model('smsproviders');
       
       $data['prow']=  $this->smsproviders->getsmsprovider($id);
       $this->load->view('smsprovideredit',$data);
   }
   
    function addprovider()
    {
         $this->load->library('form_validation');
	
      $this->form_validation->set_rules("refurl","Refurl","required"); 
      $this->form_validation->set_rules("uboxename","Uboxename","required");
      $this->form_validation->set_rules("pboxname","Pboxname","required");
      $this->form_validation->set_rules("buttonname","Buttonname","required");
      $this->form_validation->set_rules("msgrefurl","Msgrefurl","required");
      $this->form_validation->set_rules("senderboxname","Senderboxname","required");
      $this->form_validation->set_rules("sendbouttonname","sendbouttonname","required");
      
      $this->form_validation->set_rules("logurl","Logurl","required");
      $this->form_validation->set_rules("username","Username","required");
      $this->form_validation->set_rules("password","Password","required");
      $this->form_validation->set_rules("logbuttonvalue","Logbuttonvalue","required");
      $this->form_validation->set_rules("messageurl","Messageurl","required");
      $this->form_validation->set_rules("msgboxname","Msgboxname","required");
      $this->form_validation->set_rules("sendbuttonvalue","Sendbuttonvalue","required"); 
    
      
       $id=$this->input->post('pid');
	 
	    if ( $this->form_validation->run() !== false ) {
			  $this->load->model('providerlist');
                          $logref=$this->input->post('refurl');
			$uboxename=$this->input->post('uboxename');
			$pboxname=$this->input->post('pboxname');
			$buttonname=$this->input->post('buttonname');
                        $msgrefurl=$this->input->post('msgrefurl');
                        $senderboxname=$this->input->post('senderboxname');
                        $sendbouttonname=$this->input->post('sendbouttonname');
                        
                        $logurl=$this->input->post('logurl');
                        $username=$this->input->post('username');
                        $password=$this->input->post('password');
                        $logbuttonvalue=$this->input->post('logbuttonvalue');
                        $messageurl=$this->input->post('messageurl');
                        $msgboxname=$this->input->post('msgboxname');
                        $sendbuttonvalue=$this->input->post('sendbuttonvalue');
                       
                      
                                $this->load->model('smsproviders');
                                $this->smsproviders->editprovider($id,$logref,$logurl,$uboxename,$username,$pboxname,$password,$buttonname,$logbuttonvalue,$msgrefurl,$messageurl, $senderboxname,$msgboxname,$sendbouttonname,$sendbuttonvalue);
                                
                                
                                redirect('smsmaincontrol/smsprovider');
                          
                            
                     
                        
                
      
            
             
    }else{
        $this->editsmsprovidered($id);
            
                            
    }
    }
    function deletesmsprovider($id){
        $this->load->model('smsproviders');
         $this->smsproviders->deletetprovider($id);
         redirect('smsmaincontrol/smsprovider');
         
    }
    
    
    
   }
      ?>