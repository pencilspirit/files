<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>

 <html>
<head>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
    <script type="text/javascript">

    $(document).ready( function () {

        setTimeout("location.reload(true);", 2000);

        $.get('welcome.php', function(ret){
            $('body').php(ret);
        });

    });

    </script>
    </head>
    <body>

<?php
class Mail extends CI_Controller{
    function __construct() {
        parent::__construct();
       
    }
    function index()
    {
        
        
        if($this->emailcheck())
        {
        $this->getemail();
        }
        
       }
       function emailcheck(){
           $this->load->model('unreadmails');
           $myflag=$this->unreadmails->unreadmail();
           return $myflag;
       }
       function getemail(){
           $ncontant="";
           $contant="";
           $mystatus=0;
           $unknowng;
           $knowno;
           $unknowno;
           $ungroupflag=0;
           $unknownoflag=0;
           $knownoflag=0;
           $knowngflag=0;
            $this->load->model('getmaildata');
           $data=$this->getmaildata->fetchsubject();
           $num=$this->sliptnumber($data[0]);
           $grow=$this->sliptgroup($data[0]);
           $glen=count($grow);
           if($glen>0){
             
$len=  count($grow);
if($len>0){
$i=0;
$u=0;
$k=0;
$unknowno;
$knowno;
$this->load->model('numbercheck');
while ($i<$len){
    $this->load->database();
    $this->db->reconnect();
    $yesno=$this->numbercheck->groupishere($grow[$i]);
    if($yesno==1){
        $knowno[$k]=$grow[$i];
        $knownoflag=1;
        
        $k++;
    }
    else
    {
        $unknowno[$u]=$grow[$i];
       $unknownoflag=1;
        $u++;
        
    }
    $i++;
}
if($unknownoflag==1){

    $t=0;
    $mystatus=1;
    $contant='This group are not in the directory';
    while($t<  count($unknowno)){
        $contant=$contant.",".$unknowno[$t];
        $t++;
        
    }
  
} else {
    $contant="";
}
           }
           
           }
           
           
           
           
           
            $len=  count($num);
           if($len>0)           {
          
          
               
$i=0;
$u=0;
$k=0;
$unknowng;
$knowng;
$this->load->model('numbercheck');
while ($i<$len){
    $this->load->database();
    $this->db->reconnect();
    $yesno=$this->numbercheck->numberishere($num[$i]);
    if($yesno==1){
        $knowng[$k]=$num[$i];
        $knowngflag=1;
        $k++;
    }
    else
    {
        $unknowng[$u]=$num[$i];
        
             $ungroupflag=1;   
        $u++;
    }
    $i++;
}

if($ungroupflag==1){
$ulen=  count($unknowng);

    $t=0;
    $mystatus=1;
    $ncontant='This number are not in the directory';
    while($t < $ulen){
       $ncontant=$ncontant.",". $unknowng[$t];
        $t++;
        
    }
    
    
 
    
}else{
    $ncontant="";
}
           
           
           }
           if($mystatus==1){
               $totalcon= $ncontant."  ".$contant;
              
               $this->load->database();
               $this->db->reconnect();
               $this->load->model('sendemail');
               
               $this->sendemail->sendunknowemail($totalcon,$data[2]);

               
               
           }
           
           if($knowngflag==1)
                   {
               if(count($knowng)>0){
                    $this->load->model('asms');
                   for($nu=0;$nu<count($knowng);$nu++){
                       $this->load->database();
                        $this->db->reconnect();

                      
                        $this->asms->sendsms($knowng[$nu],$data[1]);
                   }
               }
               
               
           }
           
          if($knownoflag==1){
           
                if(count($knowno)>0){
                    $gnumber=array();
                    for($r=0;$r<count($knowno);$r++){
                        
                    
                    $gnumber=array_merge($gnumber,$this->getgroupnumber($knowno[$r]));
                    
                    
                    }
                    
                    
                    
                    
                    $arr=$gnumber;
                    $len = count($arr);
for ($i = 0; $i < $len; $i++) {
  $temp = $arr[$i];
  $j = $i;
  for ($k = 0; $k < $len; $k++) {
    if ($k != $j) {
      if ($temp == $arr[$k]) {
       
        $arr[$k]="";
      }
    }
  }
}
 $this->load->model('asms');
for ($i = 0; $i < $len; $i++) {
   
            $this->load->database();
            $this->db->reconnect();

	
         if(!trim($arr[$i])=="")
         {
             $this->asms->sendsms($arr[$i],$data[1]);
         } 
}
                    
 
                }
            }
            
           
       }
       function getgroupnumber($group){
           
           $this->load->model('numbercheck');
           $num=$this->numbercheck->getgroupnumber($group);
          return $num;
           
           
       }
       function sliptnumber($data){
           $str = $data;
$flag=1;
            $sub = preg_split("/,/", $str);
            $k=0;
            foreach ($sub as $subject){
             $temp =  preg_split("/,/", $subject);
            if($temp){
                foreach ($temp as $temps){
                $emailsub[$k]= $temps;   
                $k++;
                        } 
            } else {
            $emailsub[$k]= $subject;    
                $k++;
            }
            }
            
            $len=  count($emailsub);
$j=0;
$n=0;
$g=0;
while($j<$len){
   $data=  strip_tags($emailsub[$j]);
 
    if(!is_numeric($data)){
        
     $group[$g]= $emailsub[$j];
     
       $g++;
        
    } else {
        
    $number[$n]=$emailsub[$j];
   $flag=0;
    $n++;
        
    } $j++;   
    }  
    if($flag==0){
       return $number; 
    }
    
    
}

function sliptgroup($data){
           $str = $data;
           $flag=1;

            $sub = preg_split("/,/", $str);
            $k=0;
            foreach ($sub as $subject){
             $temp =  preg_split("/,/", $subject);
            if($temp){
                foreach ($temp as $temps){
                $emailsub[$k]= $temps;   
                $k++;
                        } 
            } else {
            $emailsub[$k]= $subject;    
                $k++;
            }
            }
            
            $len=  count($emailsub);
$j=0;
$n=0;
$g=0;
while($j<$len){
   $data=  strip_tags($emailsub[$j]);
 
    if(!is_numeric($data)){
        $flag=0;
     $group[$g]= $emailsub[$j];
     
       $g++;
        
    } else {
        
    $number[$n]=$emailsub[$j];
   
    $n++;
        
    } $j++;   
    }   
    if($flag==0)
    {
       return $group; 
    }
    
}

}


?>
 </body>
    </html>