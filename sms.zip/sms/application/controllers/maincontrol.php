<?php
class Maincontrol extends CI_Controller{
    function __construct() {
        parent::__construct();
        session_start();
    }
    function index(){
    
}

 public function mailnumbers($number)
         
    {
     $this->load->model('asms');
     $this->asms->mine();
 }

}
?>
