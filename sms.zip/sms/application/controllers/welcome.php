<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
?>
 <html>
<head>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
    <script type="text/javascript">

    $(document).ready( function () {

        setTimeout("location.reload(true);", 2000);

        $.get('welcome.php', function(ret){
            $('body').php(ret);
        });

    });

    </script>
    </head>
    <body style="background:#06F;width:100%;height:1000px">
<?php
class Welcome extends CI_Controller {

   function __construct()
   {
     
      parent::__construct();
     
   }
   function index()
   {
    $numbered=array('7795398584','8088184192');
	 $mbox = imap_open("{imap.gmail.com:993/imap/ssl}INBOX", "jibi@pluskb.com", "Reset123")
     or die("can't connect: " . imap_last_error());
		 $numMessages = imap_num_msg($mbox);
$i = $numMessages; 
while($i!=0){
 $headers = imap_headerinfo($mbox, $i);
    if($headers->Unseen == 'U') {
    $header = imap_header($mbox, $i);

    $fromInfo = $header->from[0];
    $replyInfo = $header->reply_to[0];

    $details = array(
        "fromAddr" => (isset($fromInfo->mailbox) && isset($fromInfo->host))? $fromInfo->mailbox . "@" . $fromInfo->host : "",
       "fromName" => (isset($fromInfo->personal)) ? $fromInfo->personal : "",
        "replyAddr" => (isset($replyInfo->mailbox) && isset($replyInfo->host))? $replyInfo->mailbox . "@" . $replyInfo->host : "",
      
        "subject" => (isset($header->subject))
            ? $header->subject : "",
       
    );

    $uid = imap_uid($mbox, $i);
	if($details["fromAddr"]=='pluskbhosting@gmail.com'){
		

	
	if($details['subject']=='jibi'){
	 $sata= imap_fetchbody($mbox,$i,2);
	 $message=strip_tags($sata);
	
	 $this->load->model('asms');
	 $this->asms->sendsms($numbered[0],$message);
}
if($details['subject']=='all'){
	$j=0;
	$len=count($numbered);
	 $sata= imap_fetchbody($mbox,$i,2);
	 $message=strip_tags($sata);
	while($j<$len)
		{
	 $this->load->model('asms');
	 $this->asms->sendsms($numbered[$j],$message);
	 $j++;
		}
}
	if($details['subject']=='pluskb'){
	 $sata= imap_fetchbody($mbox,$i,2);
	 $message=strip_tags($sata);
	
	 $this->load->model('asms');
	 $this->asms->sendsms($numbered[1],$message);
}
	
	
	

	}
 
	}
	$i--;
	
	}
	 
		
		
	
?>
<?php /*?>$mbo['mbox'] = imap_open("{imap.gmail.com:993/imap/ssl}INBOX", "jibi@pluskb.com", "Reset123")
     or die("can't connect: " . imap_last_error());

$this->load->view('inbox',$mbo);<?php */?><?php




   }
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
?>

    </body>
    </html>