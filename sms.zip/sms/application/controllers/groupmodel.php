<?php
class Groupmodel extends CI_Model
{
    function __construct() {
        parent::__construct();
    }
    function getgroup()
        {
        $this->db->select()->from('Group');
        $sql=  $this->db->get();
        return $sql->result();
    }
    function getmemberlist(){
        
         $this->db->select()->from('members');
        $sql=  $this->db->get();
        return $sql->result();
                
    
        
    }
    function checkgroup($gname){
        $data=FALSE;
        $this->db->select()->from('Group')->where('groupname',$gname);
        $sql=  $this->db->get();
         if ( $sql-> num_rows() >0 ){
          $data= TRUE;
      }  else {
          $data=FALSE;
      }
      return $data;
    }
    function addgroup($name)
    {
        $data=array(
            'groupname'=>$name
        );
        $this->db->insert('Group',$data);
    }
      public function record_count() {
        return $this->db->count_all("Group");
    }
     public function fetch_countries($limit, $start) {
        $this->db->limit($limit, $start);
        $query = $this->db->get("Group");

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   }
   
   
     public function memberrecord_count() {
        return $this->db->count_all("members");
    }
     public function fetch_member($limit, $start) {
        $this->db->limit($limit, $start);
        $query = $this->db->get("members");

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   }
   
   function checkgroupforedit($gname,$orgial){
       
       
       $this->db->select()->from('Group')->where('groupname',$orgial);
       $sql=  $this->db->get();  
       
         foreach ($sql->result() as $row) {
           
                 $data= $row->id;  
                 
               
    }
     $this->db->select()->from('Group')->where('id <>',$data)->where('groupname',$gname);
       $query=  $this->db->get();  
$datat=FALSE;
         if($query-> num_rows() >0){
           $datat=TRUE;
       }else{
           $datat=FALSE;
       }
       return $datat;
   }
   function groupedit($gname,$orgial){
         $data=array(
         'groupname'=>$gname);
         $this->db->where('groupname',$orgial);
        $this->db->update('Group',$data);
   }
   
   
   
   function checkmemberforedit($id,$usergroup){
       
       
    
     $this->db->select()->from('memberz')->where('id <>',$id)->where('groupname',$gname);
       $query=  $this->db->get();  
$datat=FALSE;
         if($query-> num_rows() >0){
           $datat=TRUE;
       }else{
           $datat=FALSE;
       }
       return $datat;
   }
   function groupedited($id,$gname,$email){
       
       $this->db->select()->from('memberz')->where('id <>',$id)->where('groupname',$gname)->where('email',$email);
       $query=  $this->db->get();  
$datat=FALSE;
         if($query-> num_rows() >0){
           $datat=TRUE;
       }else{
           $datat=FALSE;
       }
       return $datat;
         
   }
   function updatedata($id,$name,$email,$gname,$number){
       $goup=array(
            'gname'=>$gname,
            'number'=>$number
        );
       
        $data=array(
        'name'=>$name,
        'number'=>$number,
        'email'=>$email,
        'groupname'=>$gname);
         $this->db->where('id',$id);
        $this->db->update('members',$data);
         $this->db->where('mid',$id);
        $this->db->update('smsgroup',$goup);
   }
}

?>
