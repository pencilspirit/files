<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mamilbox extends CI_Controller {
	  
		
		 var $login;
        var $curl;
        var $token; 
   function __construct()
   {
      session_start();
      parent::__construct();
	   include_once 'CurlProcess.php';
	    $this->login    =   FALSE;
        
	 
     
   }
   function read($data)
   {
	    $mbox = imap_open("{imap.gmail.com:993/imap/ssl}INBOX", "jibi@pluskb.com", "Reset123")
     or die("can't connect: " . imap_last_error());
	 $myvalue['data']=imap_header($mbox,$data);
 
  
    $this->load->view('unread',$myvalue);
	
   
   }
   function sendsms($number,$sub)
   {
	   $subject=trim($sub);
	   
	  $number=array('7795398584','8088184192');
	 
		$len=count($number);
		$i=0;
	    $this->curl     =   new CurlProcess();
			 $post_data  =   "LoginForm[username]=jibi343&LoginForm[password]=Reset@123&yt0=Login";
            $url        =   "http://www.indyarocks.com/login";
            $ref        =   "http://www.indyarocks.com";
            $content    =   ($this->curl->post($url,$post_data,$ref));

            $regex      =   '/name="Token" id="Token" value="(.*)"/';
            preg_match($regex,$content,$match);
              
		while($i<$len)
		{
			 $post_data  =   "FreeSms[mobile]=$number[$i]&FreeSms[post_message]=$subject&yt0=SEND";
            $url        =   "http://www.indyarocks.com/send-free-sms";
            $ref        =   "http://www.indyarocks.com/profile#Discover";
            $content    =   ($this->curl->post($url,$post_data,$ref));

            $regex      =   '/name="Token" id="Token" value="(.*)"/';
            preg_match($regex,$content,$match);
			$i++;
		}
	   
	  
	    
		
			
			
	
			
			


   }
   
}


?>