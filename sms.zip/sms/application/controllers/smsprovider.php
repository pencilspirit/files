<?php

class Smsprovider extends CI_Controller{
    function __construct() {
        parent::__construct();
        
    }
    function index()
    {
       
    }
    
    function addprovider()
    {
         $this->load->library('form_validation');
	
      $this->form_validation->set_rules("refurl","Refurl","required"); 
      $this->form_validation->set_rules("uboxename","Uboxename","required");
      $this->form_validation->set_rules("pboxname","Pboxname","required");
      $this->form_validation->set_rules("buttonname","Buttonname","required");
      $this->form_validation->set_rules("msgrefurl","Msgrefurl","required");
      $this->form_validation->set_rules("senderboxname","Senderboxname","required");
      $this->form_validation->set_rules("sendbouttonname","sendbouttonname","required");
      
      $this->form_validation->set_rules("logurl","Logurl","required");
      $this->form_validation->set_rules("username","Username","required");
      $this->form_validation->set_rules("password","Password","required");
      $this->form_validation->set_rules("logbuttonvalue","Logbuttonvalue","required");
      $this->form_validation->set_rules("messageurl","Messageurl","required");
      $this->form_validation->set_rules("msgboxname","Msgboxname","required");
      $this->form_validation->set_rules("sendbuttonvalue","Sendbuttonvalue","required"); 
      
      
	  
	    if ( $this->form_validation->run() !== false ) {
			  $this->load->model('smsproviders');
                          $logref=$this->input->post('refurl');
			$uboxename=$this->input->post('uboxename');
			$pboxname=$this->input->post('pboxname');
			$buttonname=$this->input->post('buttonname');
                        $msgrefurl=$this->input->post('msgrefurl');
                        $senderboxname=$this->input->post('senderboxname');
                        $sendbouttonname=$this->input->post('sendbouttonname');
                        
                        $logurl=$this->input->post('logurl');
                        $username=$this->input->post('username');
                        $password=$this->input->post('password');
                        $logbuttonvalue=$this->input->post('logbuttonvalue');
                        $messageurl=$this->input->post('messageurl');
                        $msgboxname=$this->input->post('msgboxname');
                        $sendbuttonvalue=$this->input->post('sendbuttonvalue');

     $this->smsproviders->addprovider($logref,$logurl,$uboxename,$username,$pboxname,$password,$buttonname,$logbuttonvalue,$msgrefurl,$messageurl, $senderboxname,$msgboxname,$sendbouttonname,$sendbuttonvalue);
                        
                       
                       
            }else{
                
        $this->load->view('smsprovideradd');
            }
             
    }
}
?>
