<?php  if(!isset($_SESSION['user'])){
    
      redirect('smsmaincontrol/login');
}else{
    
    
    ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>SMS</title>
 

  <!-- Le styles -->
  <link href="<?php echo base_url();?>css/bootstrap.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/bootstrap-responsive.min.css" rel="stylesheet">
  <link href="<?php echo base_url();?>css/docs.css" rel="stylesheet">
  <link rel='stylesheet' href='<?php echo base_url();?>css/prettify.css' />

	<link rel="stylesheet" href="<?php echo base_url();?>css/fullcalendar.css">
	<link rel="stylesheet" href="<?php echo base_url();?>css/toastr.css">
 
  <script src="<?php echo base_url();?>js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>js/bootstrap.js"></script>
  <script src="<?php echo base_url();?>js/jquery.knob.js"></script>
  <script src="<?php echo base_url();?>js/jquery.sparkline.min.js"></script>
  <script src="<?php echo base_url();?>js/toastr.js"></script>
  <script src="<?php echo base_url();?>js/jquery.tablesorter.min.js"></script>
  <script src="<?php echo base_url();?>js/jquery.peity.min.js"></script>
  <script src="<?php echo base_url();?>js/fullcalendar.min.js"></script>
  <script src="<?php echo base_url();?>js/gcal.js"></script>
  <script src="<?php echo base_url();?>js/prettify/prettify.js"></script>
 

  <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
  </head>
  
  <body>
  
	
 
	  <div class="navbar navbar-fixed-top">
	
			<div class="navbar-inner">
				
				<div class="container">
					
					<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</a>
					
					<a class="brand pull-left" href="./">
						<img style="margin-right:20px" src="<?php echo base_url();?>image/group_logo.png"/>				
					</a>		
					
					<div class="nav-collapse">
						<ul class="nav pull-right">
					
							<li class="dropdown">
								
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" style="margin-top:10px">
									<i class="icon-user"></i> 
									admin									<b class="caret"></b>
								</a>
								
								<ul class="dropdown-menu">
									<li><a href="">My Profile</a></li>
									<li class="divider"></li>
                                                                        <li><a href="<?php echo base_url();?>index.php/smsmaincontrol/logout">Logout</a></li>
								</ul>
								
							</li>
						</ul>
						
					</div><!--/.nav-collapse -->	
			
				</div> <!-- /container -->
				
			</div> <!-- /navbar-inner -->
			
		</div> <!-- /navbar -->
		
		<!-- Main Content
    ================================================== -->
		<div class="main">

			<div class="main-inner">

			    <div class="container">
			    
			    	<div class="row">
			    	
							<div class="span3 bs-docs-sidebar" style="margin-top:50px; min-height:600px">
								<!-- Secondary vertical navigation
						    ================================================== -->
								<ul class="nav nav-list bs-docs-sidenav">
								  <li class=' sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/login"><img style="margin-right:20px;" src="<?php echo base_url();?>image/glyphicons_041_charts.png"/>Dashboard</a></li>
								  <li class='  sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/sendsmsnow"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_124_message_plus.png"/>Send Message</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/sendsmslist"><img style="margin-right:25px" src="<?php echo base_url();?>image/glyphicons_123_message_out.png"/>SMS log</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/receiveemail"><img style="margin-right:26px" src="<?php echo base_url();?>image/glyphicons_077_headset.png"/>Email log</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/smsprovider"><img style="margin-right:23px" src="<?php echo base_url();?>image/glyphicons_127_message_flag.png"/>Sms Provider</a></li>
								  <li class='active sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/getgroups"><img style="margin-right:18px" src="<?php echo base_url();?>image/glyphicons_024_parents.png"/>Contact Groups</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/alcontacts"><img style="margin-right:19px" src="<?php echo base_url();?>image/glyphicons_024_parents.png"/>All Contacts</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/myaccout"><img style="margin-right:26px" src="<?php echo base_url();?>image/glyphicons_044_keys.png"/>My Account</a></li>
								  <li class='sub-nav-line'><a href="<?php echo base_url();?>index.php/smsmaincontrol/setup"><img style="margin-right:16px" src="<?php echo base_url();?>image/glyphicons_137_cogwheels.png"/>Setup</a></li>
									
								</ul>
								
							</div>
							
                                    
                                    
                                                                        
                              
                                    
  <script type="text/javascript" charset="utf-8">
      
<?php if($_SESSION['addmember']=="down") {
     $_SESSION['addmember']="null";?> 
						toastr.success('New Member Is Successfully Added !');
                                                
 <?php 
 
         
 
 } if($_SESSION['addmember']=="alredy") {
     $_SESSION['addmember']="null";?>                            
                                    
  

	toastr.error('This Member is Already Registered In This Group!');
        
		

<?php 

} ?>
  <?php if($_SESSION['addmember']=="error") {
      $_SESSION['addmember']="null";
      ?>                            
                                    
  
$_SESSION['addmember']="null";
	toastr.error('Please Enter the Correct Details!');
        

		

<?php } ?>
				    				    

	$(document).ready(function() {
	
		// Pass the id of group to modal
		$(document).on("click", ".open-contact", function () {
		     var groupId = $(this).data('id');
		     var groupName = $(this).data('name');
		     $(".modal-body #GroupID").val( groupId );
		     $(".modal-body #GroupName").val( groupName );
		    $('#addContact').modal('show');
		});
	
		// Ajax add appointment
		
		
		// Ajax add group
				
		
		// Ajax Remove contact
		$(".deleteUser").click(function(e) {
			e.preventDefault();
			$.ajax({
				url: $(this).attr('href'),
				success: function(data) {
					
					if( data.success = true )
					{
						toastr.error('Contact deleted!');
						setTimeout(function () {
							window.location.reload();
						}, 1000);
					}
					
				}
			});

		});
					
				
		});


		
</script>

		<div class="span9" style="margin-top:40px">
			
			<div class="row">
				<div class="span9">
					<h4>Groups</h4>
				</div>
				<div class="span3">
					<div class="well well-col" align="center">
						<a href="#addGroup" role="button" data-toggle="modal" class="btn btn-danger"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_043_group_22h.png"/>New Group</a>
					</div><!-- /well -->
				</div><!-- /span3 -->
				
				<div class="span3">
					<div class="well well-col" align="center">
						<a href="" role="button" class="btn btn-danger"><img style="margin-right:20px" src="<?php echo base_url();?>image/glyphicons_043_group_22h.png"/>Manage Groups</a>
					</div><!-- /well -->
				</div><!-- /span3 -->
				
				<div class="span3">
					<div class="well well-col" style="min-height:33px" align="center">

					</div><!-- /well -->
				</div><!-- /span3 -->

			</div><!-- /row -->
			
		</div><!-- /row -->
		
<div class="row">
	<div class="span9">
		<h4>All Groups</h4>
	</div>
			
				<?php foreach ($row as $myrow){
                                    $io=0;
                                foreach ($mrow as $merow)
                                {
                                    if($myrow->groupname==$merow->groupname){
                                        $io++;
                                    }
                                }
                                    ?>
                                	
				
			<div class="span3">
				<h4><?php echo $myrow->groupname ?></h4>
				<div class="well well-col">
					<div class="row-fluid">
						<h1 style="font-size:30px" align="center"><img style="margin-right:20px" src="<?php echo base_url();?>/image/glyphicons_024_parents.png"/> <?php echo $io;?></h1>
					</div><!-- /row-fluid -->
					<div class="row-fluid" align="center">	
						<a data-toggle="modal" data-id="33" data-name="<?php echo $myrow->groupname ?>" data-toggle="modal" title="Add this item" class="open-contact btn btn-default btn-small" href="#addContact"<i class="icon-user"></i>  Add contact</a>
						
					</div><!-- /row-fluid -->
				</div><!-- /well -->
			</div><!-- /span3 -->
<?php } ?>
                        
				
			

				
			

						</div><!-- /row -->
		
</div><!-- /span9 -->
 
<!-- Modal -->
<div id="addContact" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		<h3 id="myModalLabel" class="black">New Contact</h3>
	</div><!-- /modal-header -->
	<div class="modal-body text-grey">
            <?php $attributes = array(
                                
                                'class'=>'form-horizontal',
                                'enctype'=>'multipart/form-data'
                                );echo form_open('smsmaincontrol/addmember',$attributes)?>
            	<div class="control-group">
				<label class="control-label" for="inputName">Name</label>
				<div class="controls">
					<input type="text" name="name" placeholder="Name" value="">
				</div><!-- /controls -->
			</div><!-- /control-group -->
			
			<div class="control-group">
				<label class="control-label" for="inputSurname">Number</label>
				<div class="controls">
					<input type="text" name="phone" placeholder="Phone" value="">
				</div><!-- /controls -->
			</div><!-- /control-group -->
			
			<div class="control-group">
				<label class="control-label" for="inputEmail">Email</label>
				<div class="controls">
					<input type="text" name="email" placeholder="Email"  value="">
				</div><!-- /controls -->
			</div><!-- /control-group -->
			
			
			
			<div class="control-group">
				<label class="control-label" for="inputMobile">Group</label>
				<div class="controls">
					<input type="text" name="groupName" id="GroupName" value="" disabled>
                                        <input type="hidden" name="groupName" id="GroupName" value="">
					
                                        
				</div><!-- /controls -->							
				<div class="clear_10"></div>
			</div><!-- /control-group -->
	
	</div>
	<div class="modal-footer">
		<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
		<button class="btn btn-primary" type="submit">Save changes</button>
	</div><!-- /modal-footer -->
		</form><!-- /form -->
      
</div><!-- /modal -->

<!-- Modal -->
<div id="addGroup" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		<h3 id="myModalLabel" class="black">New Group</h3>
	</div>
	<div class="modal-body text-grey">
		 <?php $attributes = array(
                                
                                'class'=>'form-horizontal',
                                'enctype'=>'multipart/form-data'
                                );echo form_open('smsmaincontrol/addnewgroup',$attributes)?>
			<div class="control-group">
				<label class="control-label" for="inputName">Group description</label>
				<div class="controls">
					<input type="text" name="name" placeholder="name" value="">
				</div><!-- /controls -->
			</div><!-- /control-group -->
			
	</div>
	<div class="modal-footer">
		<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
		<button class="btn btn-primary" type="submit">Save changes</button>
	</div><!-- /modal-footer -->
		</form><!-- /form -->
</div><!-- /modal -->				    

			    </div> <!-- /container -->

			</div> <!-- /main-inner -->

  

			<div class="footer-inner">
				
				<div class="container">
					
					<div class="row">
						
		    			<div class="span12">
		    				&copy; Rensco 2012 <a href="#"></a>.
		    			</div> <!-- /span12 -->
		    				</div> <!-- /row -->
		    		
				</div> <!-- /container -->
				
			</div> <!-- /footer-inner -->

  </body>
</html>

<?php
}
?>