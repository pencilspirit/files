<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 class Member extends CI_Controller
 {
     function __construct() {
         parent::__construct();
         
           session_start();
     }
     function index()
     {
     
         $this->load->model('smsmember')      ;
       $data['row']= $this->smsmember->getmember(); 
       $this->load->view('smsmemberview',$data);
      
     }
     function add()
     {
         $this->load->model('group') ;
         $data['row']= $this->group->getgroup();
         $this->load->view('memberadd',$data);
     }
     function cancel()
     {
       $this->load->model('smsmember')      ;
       $data['row']= $this->smsmember->getmember();
       $this->load->view('smsmemberview',$data);
     }
     function edit($id)
     { 
         $_SESSION['editid']=$id;
          $this->load->model('smsmember')      ;
      
            $data['editrow']= $this->smsmember->editmember($id);
         $this->load->model('group')      ;
         $data['row']= $this->group->getgroup();
         $this->load->view('memberedit',$data);
         
        
            
         
     }
     function update(){
         $this->load->library('form_validation');
	
      $this->form_validation->set_rules("name","Name","required"); 
      $this->form_validation->set_rules('phone', 'Phone', 'required|regex_match[/^[0-9]+$/]|xss_clean');
    
      $this->form_validation->set_rules("usergroup","Usergroup","required"); 
      $this->form_validation->set_rules('email', 'Email', 'valid_email|required');
      
	  
	    if ( $this->form_validation->run() !== false ) {
			  $this->load->model('smsmember');
                          $name=$this->input->post('name');
			$phone=$this->input->post('phone');
			$email=$this->input->post('email');
			$usergroup=$this->input->post('usergroup');
                        $satus=$this->smsmember->chechingedit($_SESSION['editid'],$usergroup);
                        if($satus==TRUE){
                            
                            $this->smsmember->updatedata($name,$phone,$email,$usergroup,$_SESSION['editid']);
                         echo "sussesfully updated";
                            $this->load->model('smsmember')      ;
                            $data['row']= $this->smsmember->getmember(); 
                            $this->load->view('smsmemberview',$data);
                        }else{
                         if($this->smsmember->cheching($phone,$usergroup)){
                            echo "The member is alredy Register in this group";
                            
                            $this->load->model('smsmember');
        
         $data['editrow']= $this->smsmember->editmember( $_SESSION['editid']);
         $this->load->model('group')      ;
         $data['row']= $this->group->getgroup();
         $this->load->view('memberedit',$data);
                            }
                            
                            else{
                         $this->smsmember->updatedata($name,$phone,$email,$usergroup,$_SESSION['editid']);
                         echo "sussesfully updated";
                          $this->load->model('smsmember')      ;
       $data['row']= $this->smsmember->getmember(); 
       $this->load->view('smsmemberview',$data);}}
                         
            }  else {
                 $this->load->model('smsmember');
        
         $data['editrow']= $this->smsmember->editmember( $_SESSION['editid']);
         $this->load->model('group')      ;
         $data['row']= $this->group->getgroup();
         $this->load->view('memberedit',$data);
            }
            
     }
     function addmember()
     {
          $this->load->library('form_validation');
	
      $this->form_validation->set_rules("name","Name","required"); 
      $this->form_validation->set_rules('phone', 'Phone', 'required|regex_match[/^[0-9]+$/]|xss_clean');
    
      $this->form_validation->set_rules("usergroup","Usergroup","required"); 
      $this->form_validation->set_rules('email', 'Email', 'valid_email|required');
      
	  
	    if ( $this->form_validation->run() !== false ) {
			  $this->load->model('smsmember');
                          $name=$this->input->post('name');
			$phone=$this->input->post('phone');
			$email=$this->input->post('email');
			$usergroup=$this->input->post('usergroup');
                        if($this->smsmember->cheching($phone,$usergroup)){
                            echo "The member is alredy Register in this group";
                             $this->load->model('group') ;
         $data['row']= $this->group->getgroup();
         $this->load->view('memberadd',$data);
                        }else{
                        
                         $this->smsmember->addmember($name,$phone,$email,$usergroup);
             echo "sussesfully New Member added";
                         $this->load->model('smsmember')      ;
       $data['row']= $this->smsmember->getmember();
        $this->load->view('smsmemberview',$data);}
            }else{
                $this->load->model('group') ;
         $data['row']= $this->group->getgroup();
         $this->load->view('memberadd',$data);
            }
             
     }
     function delete($id){
          $_SESSION['deleteid']=$id;
         $this->load->model('smsmember')      ;
       $this->smsmember->deletemember($id,$_SESSION['deleteid']);
      
       $data['row']= $this->smsmember->getmember(); 
       $this->load->view('smsmemberview',$data);
         
     }
     
     public function mailnumbers($number)
    {

 }
 }
?>
