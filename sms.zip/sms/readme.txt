1 unzip the file
2 create a database and upload the sms.sql from database folder
3 change the hostname db username, db passowrd, and db name in the application/config/database.php
4 change the base urlin the application/config/config.php
5 cron job host the sms/index.php/mail
6 set admin eamil id and its password 
7 set user email id
8 enjoy 