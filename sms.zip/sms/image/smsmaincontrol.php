<?php

class Smsmaincontrol extends CI_Controller{
    function __construct() {
        parent::__construct();
        session_start();
    }
    function index()
    {
        
       $this->load->view('login');
       
    }
    
    function login(){
        if(isset($_SESSION['user'])){
            $this->load->view('homesms');
        }else{
        $this->load->library('form_validation');
	
     
    
      $this->form_validation->set_rules("password","password","required"); 
      $this->form_validation->set_rules('email', 'Email', 'valid_email|required');
      
	  
	    if ( $this->form_validation->run() !== false ) {
			  $this->load->model('loginmodel');
                          $uname=$this->input->post('email');
			  $pass=$this->input->post('password');
                          $flag=$this->loginmodel->loginined($uname,$pass);
                                  if($flag===TRUE){
                                      
                                      $_SESSION['user']=$uname;
                                      $this->loginsussesfully();
                          }
                          else{
                              $_SESSION['loginm']="1";
                             $this->load->view('login'); 
                          }
            }else{
                  $this->load->view('login'); 
            }
        }
    }
   public  function loginsussesfully(){
       if(isset($_SESSION['user'])){
           $this->load->view('homesms');
       }
   }
   public function logout(){
       session_destroy();
       $this->load->view('login');
   }
   public function sendsmsnow(){
       
       
       $_SESSION['msg']="sorry";
      $data['grow']= $this->groupcheck();
       
       $data['mrow']= $this->numbercheck(); 
       
       $this->load->view('sendsmsnow',$data);
   }
   public function sendsmsforgroupe(){
        if(!isset($_SESSION['user'])){
           $this->login();
       }else{
       $this->load->library('form_validation');

      $this->form_validation->set_rules("messaage_name","messaage_name","required");
       if ( $this->form_validation->run() !== false ) {
                          $messgae=$this->input->post('messaage_name');
			  $group=$this->input->post('contact_group');
			  
                          $this->getuniquenumber($group,$messgae);
                         $data['grow']= $this->groupcheck();
                            $data['mrow']= $this->numbercheck(); 
                            $_SESSION['msg']="down";
                          //  $this->load->view('sendsmsnow',$data);
                          
                              
       
       }else{
              $_SESSION['msg']="sorry";
       $data['grow']= $this->groupcheck();
        $data['mrow']= $this->numbercheck();  
       
       $this->load->view('sendsmsnow',$data);
       }
   }
           
}

public function groupcheck() {
     $this->load->model('group')      ;
       $data= $this->group->getmembergroup();
       $newgroup=array();
       $arr=$data;
       $mn=0;
                    $len = count($arr);
for ($i = 0; $i < $len; $i++) {
  $temp = $arr[$i];
  $j = $i;
  for ($k = 0; $k < $len; $k++) {
    if ($k != $j) {
      if (strcmp($temp,$arr[$k])==0) {
       
        $arr[$k]="";
      }
    }
  }
}

for ($i = 0; $i < $len; $i++) {
   
          
	
         if(!trim($arr[$i])=="")
         {
             $newgroup[$mn]= $arr[$i];  
             $mn++;
             
             } 
}
    
    return $newgroup;
}
public function numbercheck() {
     $this->load->model('group')      ;
       $data= $this->group->getuniquenumberforsendmessage();
       $newgroup=array();
       $arr=$data;
       $mn=0;
                    $len = count($arr);
for ($i = 0; $i < $len; $i++) {
  $temp = $arr[$i];
  $j = $i;
  for ($k = 0; $k < $len; $k++) {
    if ($k != $j) {
      if (strcmp($temp,$arr[$k])==0) {
       
        $arr[$k]="";
      }
    }
  }
}

for ($i = 0; $i < $len; $i++) {
   
          
	
         if(!trim($arr[$i])=="")
         {
             $newgroup[$mn]= $arr[$i];  
             $mn++;
             
             } 
}
    
    return $newgroup;
}
public function getuniquenumber($group,$message){
    $this->load->model('group');
    $newnumber=array();
    $new=0;
        $data=$this->group->getnumberforsendmessage($group);
        
    $arr=$data;
                    $len = count($arr);
for ($i = 0; $i < $len; $i++) {
  $temp = $arr[$i];
  $j = $i;
  for ($k = 0; $k < $len; $k++) {
    if ($k != $j) {
      if ($temp == $arr[$k]) {
       
        $arr[$k]="";
      }
    }
  }
}
 $this->load->model('asms');
for ($i = 0; $i < $len; $i++) {
   if(!trim($arr[$i])=="")
         {
           
           //$this->asms->sendsms($arr[$i],$message);
       echo "hai";
          
         }
}
}
      public function sendsmsformember(){
          
          
          
              if(!isset($_SESSION['user'])){
           $this->login();
       }else{
       $this->load->library('form_validation');

      $this->form_validation->set_rules("messaage_name","messaage_name","required");
       if ( $this->form_validation->run() !== false ) {
                          $messgae=$this->input->post('messaage_name');
			  $email=$this->input->post('contact_group');
			  
                          $this->sendmessagetonumber($email,$messgae);
                         $data['grow']= $this->groupcheck();
                            $data['mrow']= $this->numbercheck(); 
                            $_SESSION['msg']="down";
                            $this->load->view('sendsmsnow',$data);
                          
                              
       
       }else{
              $_SESSION['msg']="sorry";
       $data['grow']= $this->groupcheck();
        $data['mrow']= $this->numbercheck();  
       
       $this->load->view('sendsmsnow',$data);
       }
   }
       
          
      }
      public function sendmessagetonumber($email,$messgae){
          $this->load->model('group');
        $data=$this->group->uniquenumbergetnumber($email);
           $this->load->model('asms');
           $this->asms->sendsms($data[0],$messgae);
          
      }
      function sendsmslist(){
           if(!isset($_SESSION['user'])){
           $this->login();
       }else{
           
            $this->load->helper("url");
        $this->load->model("group");
        $this->load->library("pagination");
        
	        $config["base_url"] = base_url().'index.php/smsmaincontrol/sendsmslist';
	        $config["total_rows"] = $this->group->record_count();
	        $config["per_page"] = 7;
	        $config["uri_segment"] = 3;
                $config['full_tag_open']='<div id="pagination" >';
                $config['full_tag_close']='</div>';
	 
	        $this->pagination->initialize($config);
	 
	        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $data['count']=$this->group->record_count();
	        $data["row"] = $this->group->fetch_countries($config["per_page"], $page);
	        $data["links"] = $this->pagination->create_links();
	 
           $this->load->view('smslist',$data);
           
           
       } }
       function receiveemail(){
           if(!isset($_SESSION['user'])){
           $this->login();
       }else{
           
            $this->load->helper("url");
        $this->load->model("emaillist");
        $this->load->library("pagination");
        
	        $config["base_url"] = base_url().'index.php/smsmaincontrol/receiveemail';
	        $config["total_rows"] = $this->emaillist->record_count();
	        $config["per_page"] = 7;
	        $config["uri_segment"] = 3;
                $config['full_tag_open']='<div id="pagination" >';
                $config['full_tag_close']='</div>';
	 
	        $this->pagination->initialize($config);
	 
	        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $data['count']=$this->emaillist->record_count();
	        $data["row"] = $this->emaillist->fetch_countries($config["per_page"], $page);
	        $data["links"] = $this->pagination->create_links();
	 
           $this->load->view('emaillist',$data);
           
       }
       
   }
   public function smsprovider(){
       if(!isset($_SESSION['user'])){
           $this->login();
       }else{
           
            $this->load->helper("url");
        $this->load->model("providerlist");
        $this->load->library("pagination");
        
	        $config["base_url"] = base_url().'index.php/smsmaincontrol/smsprovider';
	        $config["total_rows"] = $this->providerlist->record_count();
	        $config["per_page"] = 7;
	        $config["uri_segment"] = 3;
                $config['full_tag_open']='<div id="pagination" >';
                $config['full_tag_close']='</div>';
	 
	        $this->pagination->initialize($config);
	 
	        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $data['count']=$this->providerlist->record_count();
	        $data["row"] = $this->providerlist->fetch_countries($config["per_page"], $page);
	        $data["links"] = $this->pagination->create_links();
	 
           $this->load->view('providerlist',$data);
   }
   }
   function addnewprovider(){
       if(!isset($_SESSION['user'])){
           $this->login();
       }else{
           $_SESSION['code']='unset';
            $_SESSION['provideradd']='up';
           $this->load->view('addnewprovider');
       }
   }
    function addprovider()
    {
         $this->load->library('form_validation');
	
      $this->form_validation->set_rules("refurl","Refurl","required"); 
      $this->form_validation->set_rules("uboxename","Uboxename","required");
      $this->form_validation->set_rules("pboxname","Pboxname","required");
      $this->form_validation->set_rules("buttonname","Buttonname","required");
      $this->form_validation->set_rules("msgrefurl","Msgrefurl","required");
      $this->form_validation->set_rules("senderboxname","Senderboxname","required");
      $this->form_validation->set_rules("sendbouttonname","sendbouttonname","required");
      
      $this->form_validation->set_rules("logurl","Logurl","required");
      $this->form_validation->set_rules("username","Username","required");
      $this->form_validation->set_rules("password","Password","required");
      $this->form_validation->set_rules("logbuttonvalue","Logbuttonvalue","required");
      $this->form_validation->set_rules("messageurl","Messageurl","required");
      $this->form_validation->set_rules("msgboxname","Msgboxname","required");
      $this->form_validation->set_rules("sendbuttonvalue","Sendbuttonvalue","required"); 
      $this->form_validation->set_rules("yournumber","yournumber","required"); 
      
      
	 
	    if ( $this->form_validation->run() !== false ) {
			  $this->load->model('providerlist');
                          $logref=$this->input->post('refurl');
			$uboxename=$this->input->post('uboxename');
			$pboxname=$this->input->post('pboxname');
			$buttonname=$this->input->post('buttonname');
                        $msgrefurl=$this->input->post('msgrefurl');
                        $senderboxname=$this->input->post('senderboxname');
                        $sendbouttonname=$this->input->post('sendbouttonname');
                        
                        $logurl=$this->input->post('logurl');
                        $username=$this->input->post('username');
                        $password=$this->input->post('password');
                        $logbuttonvalue=$this->input->post('logbuttonvalue');
                        $messageurl=$this->input->post('messageurl');
                        $msgboxname=$this->input->post('msgboxname');
                        $sendbuttonvalue=$this->input->post('sendbuttonvalue');
                        $number=$this->input->post('yournumber');
                        if ($_SESSION['code']=='unset'){
                        
    $vcode=$this->providerlist->addprovider($logref,$logurl,$uboxename,$username,$pboxname,$password,$buttonname,$logbuttonvalue,$msgrefurl,$messageurl, $senderboxname,$msgboxname,$sendbouttonname,$sendbuttonvalue,$number);
               
                        
                    
                    $_SESSION['code']='set';;
                      $this->load->view('addnewprovider');
            }elseif ($_SESSION['code']=='set') {
            
                 
                        $code=$this->input->post('verificationcode');
                        
                          if($code!=""){
                            
                           if (strcmp($code,'J6i25b7723i')==0) {
                                $this->load->model('smsproviders');
                                $this->smsproviders->addprovider($logref,$logurl,$uboxename,$username,$pboxname,$password,$buttonname,$logbuttonvalue,$msgrefurl,$messageurl, $senderboxname,$msgboxname,$sendbouttonname,$sendbuttonvalue);
                                $_SESSION['provideradd']='down';
                                $_SESSION['code']='unset';
                                
                                $this->smsprovider();
                           }else
                           {
                               $_SESSION['code']='set';
                                $this->load->view('addnewprovider');
                               
                           }
                            
                            
                        }else{
                           
                              $this->load->view('addnewprovider');
                        }
                        
                
                
        }else{
            
            $_SESSION['code']=='unset';
                              $this->load->view('addnewprovider');
        }
                
            
             
    }else{
         
            $_SESSION['code']=='unset';
                              $this->load->view('addnewprovider');
    }
    }
          function addprovidered(){
               $_SESSION['code']='unset';
               $this->addnewprovider();
          }
          function getgroups(){
             
              if(!isset($_SESSION['user'])){
                   $_SESSION['addmember']="null";
                   
          $this->login();
          
       }else{
           $_SESSION['addmember']="null";
           $_SESSION['groupundo']='null';
           $this->load->model('groupmodel');
           $data['row']=  $this->groupmodel->getgroup();
           $data['mrow']=  $this->groupmodel->getmemberlist();
          
              $this->load->view('membergroup',$data);
              
          
       }
          }
          function getgroupss()
          {
                $this->load->model('groupmodel');
                $data['row']=  $this->groupmodel->getgroup();
                $data['mrow']=  $this->groupmodel->getmemberlist();      
                $this->load->view('membergroup',$data);
          }
          function addmember()
     {
              $_SESSION['addmember']='null';
          $this->load->library('form_validation');
          $_SESSION['groupundo']='null';
          
	  
      $this->form_validation->set_rules("name","Name","required"); 
      $this->form_validation->set_rules('phone', 'Phone', 'required|regex_match[/^[0-9]+$/]|xss_clean');
    
      $this->form_validation->set_rules("groupName","GroupName","required"); 
      $this->form_validation->set_rules('email', 'Email', 'valid_email|required');
      
	  
	    if ( $this->form_validation->run() !== false ) {
                 $_SESSION['validatin']='god';
			  $this->load->model('smsmember');
                          $name=$this->input->post('name');
			$phone=$this->input->post('phone');
			$email=$this->input->post('email');
			$usergroup=$this->input->post('groupName');
                        if($this->smsmember->cheching($email,$usergroup)==TRUE){
                           
                          $_SESSION['addmember']="alredy";
                            $this->getgroupss();
                        }else{
                        $_SESSION['addmember']="down";
                        
                         $this->smsmember->addmember($name,$phone,$email,$usergroup);
              
                         $this->getgroupss();
                         
                         }
            }else{
                $name=$this->input->post('name');
                
                $_SESSION['addmember']="error";
              
                $this->getgroupss();
            }
             $_SESSION['addmember']='null';
             
     }
      public function addnewgroup(){
          $_SESSION['addmember']="null";
         
       if(!isset($_SESSION['user'])){
                   
           $this->login();
          
       }else{
            $this->load->library('form_validation');
	
      $this->form_validation->set_rules("name","Name","required"); 
      
      
	  
	    if ( $this->form_validation->run() !== false ) {
                
			  $this->load->model('groupmodel');
                          $name=$this->input->post('name');
                          if($this->groupmodel->checkgroup($name)){
                              $_SESSION['groupundo']='sasi';
                              $this->getgroupss();
                          }  else {
                              
                          $this->groupmodel->addgroup($name);
                           $_SESSION['groupundo']='dow';
                           $this->getgroupss();
                              
                          }
                           
       }  else {
             $_SESSION['groupundo']='null';
            $this->getgroupss();
       }
       
   }
   }
   public function datagroupsetting()
   {
       redirect('sms/datagroupsetting');
   }
   public function alcontacts(){
        redirect('sms/memberlist');
   }
                function myaccout()                                                 
                {
                    redirect('sms/myaacount');
                }
                function setup(){
                    redirect('sms/setup');
                }
      
}
?>
