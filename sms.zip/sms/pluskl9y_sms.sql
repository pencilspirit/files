-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 03, 2013 at 05:51 PM
-- Server version: 5.1.63
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pluskl9y_sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE IF NOT EXISTS `email` (
  `id` int(100) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) NOT NULL,
  `body` varchar(255) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=60 ;

--
-- Dumping data for table `email`
--

INSERT INTO `email` (`id`, `subject`, `body`, `sender`, `date`, `status`) VALUES
(59, 'red', 'goodmorning\r\n', 'jibi@pluskb.com', '2013-05-08', '0'),
(58, 'Redjhk,hiuyi8,868686867,gjhgjhgj,8768686', 'hiuihi\r\n', 'jibi@pluskb.com', '2013-04-26', '0');

-- --------------------------------------------------------

--
-- Table structure for table `Group`
--

CREATE TABLE IF NOT EXISTS `Group` (
  `id` int(100) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `Group`
--

INSERT INTO `Group` (`id`, `groupname`) VALUES
(25, 'Red'),
(29, 'Blue');

-- --------------------------------------------------------

--
-- Table structure for table `mailnumber`
--

CREATE TABLE IF NOT EXISTS `mailnumber` (
  `id` int(200) unsigned NOT NULL AUTO_INCREMENT,
  `number` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `id` int(100) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `number` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `groupname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `name`, `number`, `email`, `groupname`) VALUES
(38, 'monish', '7795398584', 'mo@GM.COM', 'Red');

-- --------------------------------------------------------

--
-- Table structure for table `sms`
--

CREATE TABLE IF NOT EXISTS `sms` (
  `id` int(100) unsigned NOT NULL AUTO_INCREMENT,
  `number` varchar(20) NOT NULL,
  `body` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=222 ;

--
-- Dumping data for table `sms`
--

INSERT INTO `sms` (`id`, `number`, `body`, `date`) VALUES
(221, '7795398584', 'goodmorning', '2013-05-08'),
(215, '7795398584', 'good eveng', '2013-04-23');

-- --------------------------------------------------------

--
-- Table structure for table `smsgroup`
--

CREATE TABLE IF NOT EXISTS `smsgroup` (
  `id` int(100) unsigned NOT NULL AUTO_INCREMENT,
  `gname` varchar(100) NOT NULL,
  `number` varchar(15) NOT NULL,
  `mid` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `smsgroup`
--

INSERT INTO `smsgroup` (`id`, `gname`, `number`, `mid`) VALUES
(35, 'Red', '7795398584', 38);

-- --------------------------------------------------------

--
-- Table structure for table `smsprovider`
--

CREATE TABLE IF NOT EXISTS `smsprovider` (
  `id` int(100) unsigned NOT NULL AUTO_INCREMENT,
  `loginref` varchar(255) NOT NULL,
  `loginurl` varchar(255) NOT NULL,
  `textname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `passname` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `buttonname` varchar(100) NOT NULL,
  `buttonvalue` varchar(100) NOT NULL,
  `msgref` varchar(255) NOT NULL,
  `msgurl` varchar(255) NOT NULL,
  `msgnumber` varchar(100) NOT NULL,
  `msgbox` varchar(100) NOT NULL,
  `sendbutton` varchar(100) NOT NULL,
  `sendbuttonname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `smsprovider`
--

INSERT INTO `smsprovider` (`id`, `loginref`, `loginurl`, `textname`, `username`, `passname`, `password`, `buttonname`, `buttonvalue`, `msgref`, `msgurl`, `msgnumber`, `msgbox`, `sendbutton`, `sendbuttonname`) VALUES
(15, ' http://www.indyarocks.com', 'http://www.indyarocks.com/login', 'LoginForm[username]', 'jibi34', 'LoginForm[password]', 'Reset@123', 'yt0', 'Login', 'http://www.indyarocks.com/profile#Discover', 'http://www.indyarocks.com/send-free-sms', 'FreeSms[mobile]', 'FreeSms[post_message]', 'yt0', 'SEND'),
(16, ' http://www.indyarocks.com', 'http://www.indyarocks.com/login', 'LoginForm[username]', 'jibi343', 'LoginForm[password]', 'Reset@123', 'yt0', 'Login', 'http://www.indyarocks.com/profile#Discover', 'http://www.indyarocks.com/send-free-sms', 'FreeSms[mobile]', 'FreeSms[post_message]', 'yt0', 'SEND'),
(17, ' http://www.indyarocks.com', 'http://www.indyarocks.com/login', 'LoginForm[username]', 'jibi3443', 'LoginForm[password]', 'Reset@123', 'yt0', 'Login', 'http://www.indyarocks.com/profile#Discover', 'http://www.indyarocks.com/send-free-sms', 'FreeSms[mobile]', 'FreeSms[post_message]', 'yt0', 'SEND');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE IF NOT EXISTS `status` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `value` int(200) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `value`, `date`) VALUES
(1, 2, '2013-05-08');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(100) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `useremail` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `password`, `useremail`) VALUES
(1, 'ibmsalesconnect@gmail.com', 'Pass@!@#', 'sridharkalaibala@gmail.com');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
